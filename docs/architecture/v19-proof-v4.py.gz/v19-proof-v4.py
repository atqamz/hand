#!/usr/bin/env python3
"""Mechanical relock proof for docs/architecture/v19-v4.sql (atqamz/hand#344)."""
from __future__ import annotations

import argparse
import hashlib
import json
import sqlite3
import sys
from pathlib import Path

T0 = "2026-08-29T00:00:00Z"
EXPECTED_DDL_SHA256 = "4b3f4bf99a241a728c01c0de71e92fade2decee75bb3671fcef80cf329abc19f"
EXPECTED_SCHEMA_FINGERPRINT = "77c31959a7b47fd8d4035d4fcf9f425b9712b16eb413572b4af9c46d373beae8"
EXPECTED_OBJECT_COUNTS = {"tables": 57, "indexes": 39, "triggers": 175, "sql_objects": 271}


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def open_fresh(ddl: str) -> sqlite3.Connection:
    db = sqlite3.connect(":memory:", isolation_level=None)
    db.execute("PRAGMA foreign_keys=ON")
    db.executescript(ddl)
    assert db.execute("PRAGMA foreign_keys").fetchone()[0] == 1
    assert db.execute("PRAGMA user_version").fetchone()[0] == 19
    return db


def schema_fingerprint(db: sqlite3.Connection) -> str:
    rows = db.execute(
        """SELECT type,name,tbl_name,sql
           FROM sqlite_schema
           WHERE name NOT LIKE 'sqlite_%' AND sql IS NOT NULL
           ORDER BY type,name"""
    ).fetchall()
    material = "".join("|".join(str(x) for x in row) + "\n" for row in rows).encode("utf-8")
    return sha256_bytes(material)


def object_counts(db: sqlite3.Connection) -> dict[str, int]:
    counts = dict(
        db.execute(
            """SELECT type,count(*) FROM sqlite_schema
               WHERE name NOT LIKE 'sqlite_%' AND sql IS NOT NULL
               GROUP BY type"""
        ).fetchall()
    )
    auto = db.execute(
        "SELECT count(*) FROM sqlite_schema WHERE type='index' AND name LIKE 'sqlite_autoindex_%'"
    ).fetchone()[0]
    return {
        "tables": counts.get("table", 0),
        "indexes": counts.get("index", 0),
        "triggers": counts.get("trigger", 0),
        "sql_objects": sum(counts.values()),
        "sqlite_autoindexes": auto,
    }


class Fixture:
    def __init__(self, ddl: str):
        self.db = open_fresh(ddl)
        self.tick = 0

    def ts(self) -> str:
        self.tick += 1
        m, s = divmod(self.tick, 60)
        return f"2026-08-29T00:{m:02d}:{s:02d}Z"

    def execute(self, sql: str, params=()):
        return self.db.execute(sql, params)

    def op(
        self,
        oid: str,
        kind: str,
        adapter: str,
        scope_kind: str,
        scope_key: str,
        *,
        project: str = "P1",
        task: str | None = "T1",
        plan: str | None = "PL1",
        attempt: str | None = "A1",
    ) -> None:
        ts = self.ts()
        self.execute(
            """INSERT INTO external_operation
               (id,kind,adapter_ref,operation_key,request_digest,project_id,task_id,plan_id,attempt_id,
                primary_scope_kind,primary_scope_key,state,created_at,state_changed_at)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,'prepared',?,?)""",
            (
                oid,
                kind,
                adapter,
                "key-" + oid,
                "digest-" + oid,
                project,
                task,
                plan,
                attempt,
                scope_kind,
                scope_key,
                ts,
                ts,
            ),
        )

    def claim(self, oid: str, kind: str, key: str) -> None:
        self.execute(
            "INSERT INTO operation_scope_claim(operation_id,scope_kind,scope_key,created_at) VALUES(?,?,?,?)",
            (oid, kind, key, self.ts()),
        )

    def transition(self, oid: str, state: str) -> None:
        ts = self.ts()
        evidence = f"evidence-{oid}-{state}"
        if state == "submitted":
            self.execute(
                """UPDATE external_operation
                   SET state=?, state_changed_at=?, state_evidence_digest=?, submitted_at=? WHERE id=?""",
                (state, ts, evidence, ts, oid),
            )
        elif state in ("succeeded", "rejected", "no-effect"):
            self.execute(
                """UPDATE external_operation
                   SET state=?, state_changed_at=?, state_evidence_digest=?, finalized_at=? WHERE id=?""",
                (state, ts, evidence, ts, oid),
            )
        elif state == "uncertain":
            self.execute(
                """UPDATE external_operation
                   SET state=?, state_changed_at=?, state_evidence_digest=? WHERE id=?""",
                (state, ts, evidence, oid),
            )
        else:
            raise ValueError(state)

    def core(self, *, task2: bool = False) -> None:
        self.execute("INSERT INTO fleet(singleton,fleet_id,created_at) VALUES(1,'F1',?)", (self.ts(),))
        self.execute(
            "INSERT INTO project(id,fleet_id,ordinal,display_name,created_at) VALUES('P1','F1',1,'project-one',?)",
            (self.ts(),),
        )
        self.execute(
            """INSERT INTO workspace_binding
               (id,project_id,ordinal,repository_locator,repository_identity_digest,common_git_dir,
                physical_identity_digest,revision,established_at)
               VALUES('W1','P1',1,'repo://one','repository-one','/repo/.git','workspace-physical','rev0',?)""",
            (self.ts(),),
        )
        self.execute(
            """INSERT INTO policy_revision
               (id,project_id,ordinal,policy_digest,worker_profile_ref,qualification_policy_ref,
                integration_policy_ref,production_policy_ref,publication_policy_ref,created_at)
               VALUES('POL1','P1',1,'policy-one','worker-profile','qualification-policy',
                      'integration-policy','production-policy','publication-policy',?)""",
            (self.ts(),),
        )
        self.execute(
            "INSERT INTO task(id,project_id,ordinal,goal,goal_digest,created_at) VALUES('T1','P1',1,'goal one','goal-one',?)",
            (self.ts(),),
        )
        self.execute(
            """INSERT INTO plan
               (id,task_id,ordinal,lineage_kind,intent,judgment,basis,brief,brief_digest,
                workspace_binding_id,policy_revision_id,created_at)
               VALUES('PL1','T1',1,'root','execute','bounded','basis','brief','brief-one','W1','POL1',?)""",
            (self.ts(),),
        )
        self.execute(
            """INSERT INTO attempt
               (id,plan_id,ordinal,worker_harness_ref,worker_harness_version,worker_profile_ref,
                model_ref,effort_ref,session_adapter_ref,created_at)
               VALUES('A1','PL1',1,'worker-harness','v1','worker-profile','model','medium','herdr',?)""",
            (self.ts(),),
        )
        if task2:
            self.add_second_task()

    def add_second_task(self) -> None:
        self.execute(
            "INSERT INTO task(id,project_id,ordinal,goal,goal_digest,created_at) VALUES('T2','P1',2,'goal two','goal-two',?)",
            (self.ts(),),
        )
        self.execute(
            """INSERT INTO plan
               (id,task_id,ordinal,lineage_kind,intent,judgment,basis,brief,brief_digest,
                workspace_binding_id,policy_revision_id,created_at)
               VALUES('PL2','T2',1,'root','execute','bounded','basis2','brief2','brief-two','W1','POL1',?)""",
            (self.ts(),),
        )
        self.execute(
            """INSERT INTO attempt
               (id,plan_id,ordinal,worker_harness_ref,worker_harness_version,worker_profile_ref,
                model_ref,effort_ref,session_adapter_ref,created_at)
               VALUES('A2','PL2',1,'worker-harness','v1','worker-profile','model','medium','herdr',?)""",
            (self.ts(),),
        )

    def worktree(self, *, oid="O-WC1", attempt="A1", binding="WT1", path="/tmp/wt1", physical="worktree-physical") -> None:
        plan = self.execute("SELECT plan_id FROM attempt WHERE id=?", (attempt,)).fetchone()[0]
        task = self.execute("SELECT task_id FROM plan WHERE id=?", (plan,)).fetchone()[0]
        self.op(oid, "worktree-create", "builtin/git-worktree", "worktree", binding, task=task, plan=plan, attempt=attempt)
        self.execute(
            """INSERT INTO worktree_create_operation
               (operation_id,attempt_id,binding_id,requested_path,basis_revision,expected_common_git_dir,expected_lock_reason)
               VALUES(?,?,?,?,?,?,?)""",
            (oid, attempt, binding, path, "rev0", "/repo/.git", f"hand:v1:{binding}"),
        )
        self.claim(oid, "worktree", binding)
        self.transition(oid, "submitted")
        self.transition(oid, "succeeded")
        self.execute(
            """INSERT INTO attempt_worktree_binding
               (id,attempt_id,create_operation_id,path,common_git_dir,private_git_dir,lock_reason,
                basis_revision,head_revision,physical_identity_digest,established_at)
               VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
            (
                binding,
                attempt,
                oid,
                path,
                "/repo/.git",
                f"/repo/.git/worktrees/{binding}",
                f"hand:v1:{binding}",
                "rev0",
                "rev0",
                physical,
                self.ts(),
            ),
        )

    def session(self, *, oid="O-SA1", attempt="A1", worktree="WT1", binding="S1", provider="provider-s1") -> None:
        plan = self.execute("SELECT plan_id FROM attempt WHERE id=?", (attempt,)).fetchone()[0]
        task = self.execute("SELECT task_id FROM plan WHERE id=?", (plan,)).fetchone()[0]
        adapter = self.execute("SELECT session_adapter_ref FROM attempt WHERE id=?", (attempt,)).fetchone()[0]
        self.op(oid, "session-acquire", adapter, "session", binding, task=task, plan=plan, attempt=attempt)
        self.execute(
            """INSERT INTO session_acquire_operation
               (operation_id,attempt_id,worktree_binding_id,binding_id,requested_provider_session_key)
               VALUES(?,?,?,?,?)""",
            (oid, attempt, worktree, binding, provider),
        )
        self.claim(oid, "session", binding)
        self.transition(oid, "submitted")
        self.transition(oid, "succeeded")
        self.execute(
            """INSERT INTO session_binding
               (id,attempt_id,ordinal,worktree_binding_id,acquire_operation_id,adapter_ref,provider_session_key,established_at)
               VALUES(?,?,?,?,?,?,?,?)""",
            (binding, attempt, 1, worktree, oid, adapter, provider, self.ts()),
        )

    def launch(self, *, oid="O-L1", attempt="A1", session="S1", binding="E1", provider="provider-e1") -> None:
        plan = self.execute("SELECT plan_id FROM attempt WHERE id=?", (attempt,)).fetchone()[0]
        task = self.execute("SELECT task_id FROM plan WHERE id=?", (plan,)).fetchone()[0]
        adapter = self.execute("SELECT adapter_ref FROM session_binding WHERE id=?", (session,)).fetchone()[0]
        cwd = self.execute("SELECT path FROM attempt_worktree_binding WHERE attempt_id=?", (attempt,)).fetchone()[0]
        self.op(oid, "launch", adapter, "executor-control", binding, task=task, plan=plan, attempt=attempt)
        self.execute(
            """INSERT INTO launch_operation
               (operation_id,attempt_id,session_binding_id,binding_id,executable,cwd,launch_spec_digest)
               VALUES(?,?,?,?,?,?,?)""",
            (oid, attempt, session, binding, "worker", cwd, "launch-spec-digest"),
        )
        self.execute("INSERT INTO launch_argument(operation_id,ordinal,value) VALUES(?,?,?)", (oid, 0, "--run"))
        self.execute(
            """INSERT INTO launch_environment(operation_id,name,value_kind,value_material,value_digest)
               VALUES(?,?,?,?,?)""",
            (oid, "HAND_ROLE", "literal", "worker", "env-digest"),
        )
        self.claim(oid, "executor-control", binding)
        self.transition(oid, "submitted")
        self.transition(oid, "succeeded")
        self.execute(
            """INSERT INTO executor_binding
               (id,attempt_id,session_binding_id,launch_operation_id,adapter_ref,provider_executor_key,established_at)
               VALUES(?,?,?,?,?,?,?)""",
            (binding, attempt, session, oid, adapter, provider, self.ts()),
        )

    def runtime(self, *, pending_input: bool = True, task2: bool = False) -> None:
        self.core(task2=task2)
        self.worktree()
        self.session()
        self.launch()
        if pending_input:
            self.execute(
                """INSERT INTO worker_input
                   (id,attempt_id,executor_binding_id,ordinal,payload,payload_digest,origin_kind,created_at)
                   VALUES('I1','A1','E1',1,?,'input-one','operator',?)""",
                (b"first input", self.ts()),
            )


def expect_integrity_error(label: str, fn) -> str:
    try:
        fn()
    except (sqlite3.IntegrityError, sqlite3.OperationalError) as exc:
        return f"{label}: {exc}"
    raise AssertionError(f"{label}: expected SQLite rejection")


def representative_flow(ddl: str) -> dict:
    f = Fixture(ddl)
    f.runtime(pending_input=False, task2=True)

    # WorkerReport Claim and exact, distinct acknowledgement.
    f.execute(
        """INSERT INTO worker_report
           (id,attempt_id,executor_binding_id,source_prefix_digest,source_end_offset,report_state,note,created_at)
           VALUES('R1','A1','E1','report-prefix-one',100,'needs-decision','choose',?)""",
        (f.ts(),),
    )
    f.execute(
        """INSERT INTO worker_report_acknowledgement(worker_report_id,actor_kind,acknowledged_at,evidence_digest)
           VALUES('R1','supervisor',?,'report-ack')""",
        (f.ts(),),
    )

    # Decision/Answer authority, then an Answer-origin WorkerInput in one exact writer transaction.
    f.execute(
        """INSERT INTO decision
           (id,task_id,plan_id,attempt_id,scope_kind,triggering_worker_report_id,question,choices_digest,created_at)
           VALUES('D1','T1','PL1','A1','attempt','R1','Choose?','choices-one',?)""",
        (f.ts(),),
    )
    f.execute(
        """INSERT INTO decision_answer(id,decision_id,answer,answer_digest,actor_kind,actor_ref,answered_at)
           VALUES('ANS1','D1','A','answer-one','operator','operator',?)""",
        (f.ts(),),
    )
    f.execute(
        """INSERT INTO worker_input
           (id,attempt_id,executor_binding_id,ordinal,payload,payload_digest,origin_kind,created_at)
           VALUES('I1','A1','E1',1,?,'input-one','operator',?)""",
        (b"first input", f.ts()),
    )
    f.execute("BEGIN IMMEDIATE")
    f.execute(
        "INSERT INTO worker_input_answer_origin(id,worker_input_id,decision_id,answer_id) VALUES('AO1','I2','D1','ANS1')"
    )
    f.execute(
        """INSERT INTO worker_input
           (id,attempt_id,executor_binding_id,ordinal,payload,payload_digest,origin_kind,answer_origin_id,created_at)
           VALUES('I2','A1','E1',2,?,'input-two','answer','AO1',?)""",
        (b"answer A", f.ts()),
    )
    f.execute("COMMIT")

    # WorkerWake is mechanism-only and may coalesce both inputs.
    f.op("O-WAKE1", "worker-wake", "herdr", "executor-control", "E1")
    f.execute(
        """INSERT INTO worker_wake_operation
           (operation_id,attempt_id,session_binding_id,executor_binding_id,pending_through_ordinal,wake_reason,doorbell_digest)
           VALUES('O-WAKE1','A1','S1','E1',2,'pending-input','doorbell-one')"""
    )
    f.claim("O-WAKE1", "executor-control", "E1")
    f.transition("O-WAKE1", "submitted")
    f.transition("O-WAKE1", "succeeded")
    f.execute(
        """INSERT INTO worker_input_acknowledgement(worker_input_id,executor_binding_id,actor_kind,observed_at,evidence_digest)
           VALUES('I1','E1','worker',?,'ack-one')""",
        (f.ts(),),
    )
    f.execute(
        """INSERT INTO worker_input_acknowledgement(worker_input_id,executor_binding_id,actor_kind,observed_at,evidence_digest)
           VALUES('I2','E1','worker',?,'ack-two')""",
        (f.ts(),),
    )

    # Exercise Interrupt and residual-cleanup operation kinds without changing semantic input truth.
    f.op("O-INT0", "interrupt", "herdr", "executor-control", "E1")
    f.execute("INSERT INTO interrupt_operation(operation_id,attempt_id,executor_binding_id,reason_code) VALUES('O-INT0','A1','E1','probe')")
    f.claim("O-INT0", "executor-control", "E1")
    f.transition("O-INT0", "submitted")
    f.transition("O-INT0", "no-effect")

    f.op("O-RES0", "executor-residual-cleanup", "herdr", "executor-control", "E1")
    f.execute(
        """INSERT INTO executor_residual_cleanup_operation(operation_id,attempt_id,executor_binding_id,residual_identity_digest)
           VALUES('O-RES0','A1','E1','residual-one')"""
    )
    f.claim("O-RES0", "executor-control", "E1")
    f.transition("O-RES0", "submitted")
    f.transition("O-RES0", "no-effect")

    # TaskHold, Backoff, Repair each use immutable evidence + separate resolution.
    f.execute(
        """INSERT INTO task_hold(id,task_id,ordinal,kind,reason,evidence_digest,created_at)
           VALUES('H1','T1',1,'blocked','await dependency','hold-one',?)""",
        (f.ts(),),
    )
    f.execute("INSERT INTO task_hold_blocked_on_task(hold_id,blocked_on_task_id) VALUES('H1','T2')")
    f.execute("INSERT INTO task_hold_decision(hold_id,decision_id) VALUES('H1','D1')")
    f.execute("INSERT INTO task_hold_recheck(hold_id,not_before) VALUES('H1','2026-08-30T00:00:00Z')")
    f.execute(
        """INSERT INTO task_hold_resolution(hold_id,resolution,resolved_at,evidence_digest)
           VALUES('H1','released',?,'hold-resolution')""",
        (f.ts(),),
    )
    f.execute(
        """INSERT INTO attempt_backoff(id,attempt_id,ordinal,reason,not_before,evidence_digest,created_at)
           VALUES('B1','A1',1,'rate-limit','2026-08-30T00:00:00Z','backoff-one',?)""",
        (f.ts(),),
    )
    f.execute(
        """INSERT INTO attempt_backoff_resolution(backoff_id,resolution,resolved_at,evidence_digest)
           VALUES('B1','resumed',?,'backoff-resolution')""",
        (f.ts(),),
    )
    f.execute("BEGIN IMMEDIATE")
    f.execute("INSERT INTO repair_target(repair_id,executor_binding_id) VALUES('REP1','E1')")
    f.execute(
        """INSERT INTO repair(id,repair_code,reason,evidence_digest,created_at)
           VALUES('REP1','executor-observation-unknown','observe exact executor','repair-one',?)""",
        (f.ts(),),
    )
    f.execute("COMMIT")
    f.execute(
        """INSERT INTO repair_resolution(repair_id,resolution,resolved_at,evidence_digest,actor_ref)
           VALUES('REP1','repaired',?,'repair-resolution','')""",
        (f.ts(),),
    )

    # Terminal evidence, qualification, integration, production, publication.
    f.execute("UPDATE attempt SET lifecycle='completed',terminal_at=? WHERE id='A1'", (f.ts(),))
    f.execute(
        """INSERT INTO terminal_receipt(id,attempt_id,outcome_kind,candidate_revision,evidence_digest,created_at)
           VALUES('TR1','A1','candidate','candidate-rev','terminal-one',?)""",
        (f.ts(),),
    )
    f.op("O-Q1", "qualification", "qualification-adapter", "qualification", "PL1", attempt=None)
    f.execute("INSERT INTO qualification_operation(operation_id,plan_id,terminal_receipt_id,policy_revision_id) VALUES('O-Q1','PL1','TR1','POL1')")
    f.claim("O-Q1", "qualification", "PL1")
    f.transition("O-Q1", "submitted")
    f.transition("O-Q1", "succeeded")
    f.execute(
        """INSERT INTO qualification_verdict(operation_id,terminal_receipt_id,verdict,evidence_digest,decided_at)
           VALUES('O-Q1','TR1','qualified','qualification-verdict',?)""",
        (f.ts(),),
    )
    f.execute("UPDATE plan SET lifecycle='satisfied',terminal_at=? WHERE id='PL1'", (f.ts(),))

    f.op("O-IN1", "integration", "integration-adapter", "integration", "PL1", attempt=None)
    f.execute(
        """INSERT INTO integration_operation(operation_id,plan_id,terminal_receipt_id,target_ref,expected_candidate_revision)
           VALUES('O-IN1','PL1','TR1','main','candidate-rev')"""
    )
    f.claim("O-IN1", "integration", "PL1")
    f.transition("O-IN1", "submitted")
    f.transition("O-IN1", "succeeded")
    f.execute(
        """INSERT INTO integration_receipt(operation_id,plan_id,terminal_receipt_id,integrated_revision,target_ref,evidence_digest,created_at)
           VALUES('O-IN1','PL1','TR1','integrated-rev','main','integration-receipt',?)""",
        (f.ts(),),
    )

    f.op("O-PROD1", "production", "production-adapter", "production", "PL1", attempt=None)
    f.execute("INSERT INTO production_operation(operation_id,plan_id,integration_receipt_id,target_ref) VALUES('O-PROD1','PL1','O-IN1','build-target')")
    f.claim("O-PROD1", "production", "PL1")
    f.transition("O-PROD1", "submitted")
    f.transition("O-PROD1", "succeeded")
    f.execute(
        """INSERT INTO artifact(id,production_operation_id,plan_id,integration_receipt_id,artifact_kind,artifact_digest,locator,created_at)
           VALUES('ART1','O-PROD1','PL1','O-IN1','binary','artifact-one','artifact://one',?)""",
        (f.ts(),),
    )

    f.op("O-PUB1", "publication", "publication-adapter", "publication", "ART1", attempt=None)
    f.execute("INSERT INTO publication_operation(operation_id,artifact_id,target_ref) VALUES('O-PUB1','ART1','channel:stable')")
    f.claim("O-PUB1", "publication", "ART1")
    f.transition("O-PUB1", "submitted")
    f.transition("O-PUB1", "succeeded")
    f.execute(
        """INSERT INTO publication_receipt(operation_id,artifact_id,target_ref,published_identity,evidence_digest,created_at)
           VALUES('O-PUB1','ART1','channel:stable','pkg@1','publication-receipt',?)""",
        (f.ts(),),
    )

    # Resource cleanup remains exact and separate from semantic terminality.
    f.execute(
        """INSERT INTO executor_binding_termination(executor_binding_id,terminal_kind,observed_at,evidence_digest)
           VALUES('E1','completed',?,'executor-terminal')""",
        (f.ts(),),
    )
    f.op("O-SR1", "session-release", "herdr", "session", "S1")
    f.execute("INSERT INTO session_release_operation(operation_id,session_binding_id,expected_provider_session_key) VALUES('O-SR1','S1','provider-s1')")
    f.claim("O-SR1", "session", "S1")
    f.transition("O-SR1", "submitted")
    f.transition("O-SR1", "succeeded")
    f.execute(
        """INSERT INTO session_binding_release(session_binding_id,release_operation_id,released_at,evidence_digest)
           VALUES('S1','O-SR1',?,'session-release')""",
        (f.ts(),),
    )
    f.op("O-WR1", "worktree-remove", "builtin/git-worktree", "worktree", "WT1")
    f.execute(
        """INSERT INTO worktree_remove_operation
           (operation_id,binding_id,expected_physical_identity_digest,expected_common_git_dir,
            expected_private_git_dir,expected_lock_reason,expected_head_revision)
           VALUES('O-WR1','WT1','worktree-physical','/repo/.git','/repo/.git/worktrees/WT1',
                  'hand:v1:WT1','rev0')"""
    )
    f.claim("O-WR1", "worktree", "WT1")
    f.transition("O-WR1", "submitted")
    f.transition("O-WR1", "succeeded")
    f.execute(
        """INSERT INTO worktree_binding_release(binding_id,remove_operation_id,released_at,evidence_digest)
           VALUES('WT1','O-WR1',?,'worktree-release')""",
        (f.ts(),),
    )

    # Archive is one exact append-only Task fact after relational closure.
    f.execute("UPDATE task SET lifecycle='satisfied',terminal_at=? WHERE id='T1'", (f.ts(),))
    f.execute(
        """INSERT INTO task_archive(task_id,actor_kind,actor_ref,archived_at,reason,evidence_digest)
           VALUES('T1','operator','operator-1',?,'completed and reconciled',?)""",
        (f.ts(), "a" * 64),
    )

    assert f.db.execute("PRAGMA foreign_key_check").fetchall() == []
    assert f.db.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
    kinds = {r[0] for r in f.db.execute("SELECT DISTINCT kind FROM external_operation")}
    expected_kinds = {
        "worktree-create", "worktree-remove", "session-acquire", "session-release", "launch",
        "worker-wake", "interrupt", "executor-residual-cleanup", "qualification", "integration",
        "production", "publication",
    }
    assert kinds == expected_kinds, (kinds, expected_kinds)
    assert f.db.execute("SELECT count(*) FROM worker_input").fetchone()[0] == 2
    assert f.db.execute("SELECT count(*) FROM worker_input_acknowledgement").fetchone()[0] == 2
    assert f.db.execute("SELECT count(*) FROM external_operation_event").fetchone()[0] >= 3 * len(kinds)
    return {
        "operation_kinds_exercised": sorted(kinds),
        "task_archive_facts": f.db.execute("SELECT count(*) FROM task_archive").fetchone()[0],
        "integrity": "ok",
        "foreign_key_check": "empty",
    }


def build_runtime(ddl: str, *, task2=False, pending=True) -> Fixture:
    f = Fixture(ddl)
    f.runtime(pending_input=pending, task2=task2)
    return f


def adversarial_proof(ddl: str) -> list[str]:
    passed: list[str] = []

    def reject(name, setup):
        passed.append(expect_integrity_error(name, setup))

    f = Fixture(ddl); f.core()
    reject("legacy semantic send operation kind", lambda: f.op("BAD-SEND", "send", "herdr", "executor-control", "E1"))

    f = Fixture(ddl); f.core()
    reject(
        "operation cannot start submitted",
        lambda: f.execute(
            """INSERT INTO external_operation
               (id,kind,adapter_ref,operation_key,request_digest,project_id,task_id,plan_id,attempt_id,
                primary_scope_kind,primary_scope_key,state,created_at,state_changed_at,state_evidence_digest,submitted_at)
               VALUES('BAD-STATE','worktree-create','builtin/git-worktree','k','d','P1','T1','PL1','A1',
                      'worktree','WTX','submitted',?,?, 'e',?)""",
            (f.ts(), f.ts(), f.ts()),
        ),
    )

    f = Fixture(ddl); f.core(); f.op("O-NOCHILD", "worktree-create", "builtin/git-worktree", "worktree", "WTX"); f.claim("O-NOCHILD", "worktree", "WTX")
    reject("operation cannot leave prepared without typed child", lambda: f.transition("O-NOCHILD", "submitted"))

    f = Fixture(ddl); f.core(); f.op("O-NOCLAIM", "worktree-create", "builtin/git-worktree", "worktree", "WTX")
    f.execute("INSERT INTO worktree_create_operation(operation_id,attempt_id,binding_id,requested_path,basis_revision,expected_common_git_dir,expected_lock_reason) VALUES('O-NOCLAIM','A1','WTX','/tmp/x','rev0','/repo/.git','hand:v1:WTX')")
    reject("operation cannot leave prepared without primary scope claim", lambda: f.transition("O-NOCLAIM", "submitted"))

    f = build_runtime(ddl)
    reject("duplicate WorkerInput ordinal", lambda: f.execute("INSERT INTO worker_input(id,attempt_id,executor_binding_id,ordinal,payload,payload_digest,origin_kind,created_at) VALUES('I2','A1','E1',1,?,'dup','operator',?)", (b"x", f.ts())))

    f = build_runtime(ddl, task2=True)
    reject("wrong-owner ExecutorBinding WorkerInput", lambda: f.execute("INSERT INTO worker_input(id,attempt_id,executor_binding_id,ordinal,payload,payload_digest,origin_kind,created_at) VALUES('I2','A2','E1',2,?,'wrong','operator',?)", (b"x", f.ts())))

    f = build_runtime(ddl)
    f.execute("INSERT INTO worker_input_acknowledgement(worker_input_id,executor_binding_id,actor_kind,observed_at,evidence_digest) VALUES('I1','E1','worker',?,'ack')", (f.ts(),))
    reject("duplicate WorkerInput acknowledgement", lambda: f.execute("INSERT INTO worker_input_acknowledgement(worker_input_id,executor_binding_id,actor_kind,observed_at,evidence_digest) VALUES('I1','E1','worker',?,'ack2')", (f.ts(),)))

    f = build_runtime(ddl, task2=True)
    f.execute("INSERT INTO decision(id,task_id,plan_id,attempt_id,scope_kind,question,choices_digest,created_at) VALUES('D2','T2','PL2','A2','attempt','q','c',?)", (f.ts(),))
    f.execute("INSERT INTO decision_answer(id,decision_id,answer,answer_digest,actor_kind,actor_ref,answered_at) VALUES('ANS2','D2','x','a','operator','operator',?)", (f.ts(),))
    def wrong_answer_scope():
        f.execute("BEGIN IMMEDIATE")
        try:
            f.execute("INSERT INTO worker_input_answer_origin(id,worker_input_id,decision_id,answer_id) VALUES('AO2','I2','D2','ANS2')")
            f.execute("INSERT INTO worker_input(id,attempt_id,executor_binding_id,ordinal,payload,payload_digest,origin_kind,answer_origin_id,created_at) VALUES('I2','A1','E1',2,?,'x','answer','AO2',?)", (b"x", f.ts()))
        finally:
            if f.db.in_transaction:
                f.execute("ROLLBACK")
    reject("Answer-origin WorkerInput cannot retarget another Decision scope", wrong_answer_scope)

    f = build_runtime(ddl)
    f.execute("INSERT INTO decision(id,task_id,plan_id,attempt_id,scope_kind,question,choices_digest,created_at) VALUES('D1','T1','PL1','A1','attempt','q','c',?)", (f.ts(),))
    f.execute("INSERT INTO decision_answer(id,decision_id,answer,answer_digest,actor_kind,actor_ref,answered_at) VALUES('ANS1','D1','x','a','operator','operator',?)", (f.ts(),))
    def orphan_answer_origin():
        f.execute("BEGIN IMMEDIATE")
        try:
            f.execute("INSERT INTO worker_input_answer_origin(id,worker_input_id,decision_id,answer_id) VALUES('AO1','MISSING','D1','ANS1')")
            f.execute("COMMIT")
        finally:
            if f.db.in_transaction:
                f.execute("ROLLBACK")
    reject("Answer-origin helper cannot commit orphaned", orphan_answer_origin)

    f = build_runtime(ddl)
    f.op("O-MISMATCH", "interrupt", "herdr", "executor-control", "E1")
    reject("mismatched typed WorkerWake child", lambda: f.execute("INSERT INTO worker_wake_operation(operation_id,attempt_id,session_binding_id,executor_binding_id,pending_through_ordinal,wake_reason,doorbell_digest) VALUES('O-MISMATCH','A1','S1','E1',1,'wake','d')"))

    f = build_runtime(ddl)
    f.op("O-BADSCOPE", "worker-wake", "herdr", "executor-control", "OTHER")
    reject("WorkerWake primary scope must be exact executor", lambda: f.execute("INSERT INTO worker_wake_operation(operation_id,attempt_id,session_binding_id,executor_binding_id,pending_through_ordinal,wake_reason,doorbell_digest) VALUES('O-BADSCOPE','A1','S1','E1',1,'wake','d')"))

    f = build_runtime(ddl)
    f.execute("INSERT INTO worker_input_acknowledgement(worker_input_id,executor_binding_id,actor_kind,observed_at,evidence_digest) VALUES('I1','E1','worker',?,'ack')", (f.ts(),))
    f.op("O-NOPENDING", "worker-wake", "herdr", "executor-control", "E1")
    reject("WorkerWake requires unacknowledged input", lambda: f.execute("INSERT INTO worker_wake_operation(operation_id,attempt_id,session_binding_id,executor_binding_id,pending_through_ordinal,wake_reason,doorbell_digest) VALUES('O-NOPENDING','A1','S1','E1',1,'wake','d')"))

    f = build_runtime(ddl)
    f.op("O-WRACE", "worker-wake", "herdr", "executor-control", "E1")
    f.execute("INSERT INTO worker_wake_operation(operation_id,attempt_id,session_binding_id,executor_binding_id,pending_through_ordinal,wake_reason,doorbell_digest) VALUES('O-WRACE','A1','S1','E1',1,'wake','d')")
    f.claim("O-WRACE", "executor-control", "E1")
    f.op("O-IRACE", "interrupt", "herdr", "executor-control", "E1")
    f.execute("INSERT INTO interrupt_operation(operation_id,attempt_id,executor_binding_id,reason_code) VALUES('O-IRACE','A1','E1','stop')")
    reject("WorkerWake/Interrupt executor-control scope race", lambda: f.claim("O-IRACE", "executor-control", "E1"))

    f = Fixture(ddl); f.core(task2=True)
    # A2 successful create, but binding aliases current WorkspaceBinding physical identity.
    f.op("O-WC2", "worktree-create", "builtin/git-worktree", "worktree", "WT2", task="T2", plan="PL2", attempt="A2")
    f.execute("INSERT INTO worktree_create_operation(operation_id,attempt_id,binding_id,requested_path,basis_revision,expected_common_git_dir,expected_lock_reason) VALUES('O-WC2','A2','WT2','/tmp/wt2','rev0','/repo/.git','hand:v1:WT2')")
    f.claim("O-WC2", "worktree", "WT2"); f.transition("O-WC2", "submitted"); f.transition("O-WC2", "succeeded")
    reject("Worktree cannot alias current WorkspaceBinding physical identity", lambda: f.execute("INSERT INTO attempt_worktree_binding(id,attempt_id,create_operation_id,path,common_git_dir,private_git_dir,lock_reason,basis_revision,head_revision,physical_identity_digest,established_at) VALUES('WT2','A2','O-WC2','/tmp/wt2','/repo/.git','/repo/.git/worktrees/WT2','hand:v1:WT2','rev0','rev0','workspace-physical',?)", (f.ts(),)))

    f = build_runtime(ddl, task2=True)
    f.op("O-WC2", "worktree-create", "builtin/git-worktree", "worktree", "WT2", task="T2", plan="PL2", attempt="A2")
    f.execute("INSERT INTO worktree_create_operation(operation_id,attempt_id,binding_id,requested_path,basis_revision,expected_common_git_dir,expected_lock_reason) VALUES('O-WC2','A2','WT2','/tmp/wt1','rev0','/repo/.git','hand:v1:WT2')")
    f.claim("O-WC2", "worktree", "WT2"); f.transition("O-WC2", "submitted"); f.transition("O-WC2", "succeeded")
    reject("two open Worktrees cannot alias a path", lambda: f.execute("INSERT INTO attempt_worktree_binding(id,attempt_id,create_operation_id,path,common_git_dir,private_git_dir,lock_reason,basis_revision,head_revision,physical_identity_digest,established_at) VALUES('WT2','A2','O-WC2','/tmp/wt1','/repo/.git','/repo/.git/worktrees/WT2','hand:v1:WT2','rev0','rev0','other-physical',?)", (f.ts(),)))

    f = build_runtime(ddl)
    f.op("O-WROPEN", "worktree-remove", "builtin/git-worktree", "worktree", "WT1")
    reject("open SessionBinding blocks WorktreeRemove", lambda: f.execute("INSERT INTO worktree_remove_operation(operation_id,binding_id,expected_physical_identity_digest,expected_common_git_dir,expected_private_git_dir,expected_lock_reason,expected_head_revision) VALUES('O-WROPEN','WT1','worktree-physical','/repo/.git','/repo/.git/worktrees/WT1','hand:v1:WT1','rev0')"))

    f = build_runtime(ddl)
    f.op("O-SROPEN", "session-release", "herdr", "session", "S1")
    reject("open ExecutorBinding blocks SessionRelease", lambda: f.execute("INSERT INTO session_release_operation(operation_id,session_binding_id,expected_provider_session_key) VALUES('O-SROPEN','S1','provider-s1')"))

    f = build_runtime(ddl)
    f.execute("INSERT INTO attempt_backoff(id,attempt_id,ordinal,reason,not_before,evidence_digest,created_at) VALUES('B1','A1',1,'rate-limit','later','b1',?)", (f.ts(),))
    reject("multiple unresolved Backoffs", lambda: f.execute("INSERT INTO attempt_backoff(id,attempt_id,ordinal,reason,not_before,evidence_digest,created_at) VALUES('B2','A1',2,'provider-transient','later','b2',?)", (f.ts(),)))
    reject("Attempt cannot terminalize with unresolved Backoff", lambda: f.execute("UPDATE attempt SET lifecycle='failed',terminal_at=? WHERE id='A1'", (f.ts(),)))

    f = build_runtime(ddl)
    f.execute("UPDATE attempt SET lifecycle='completed',terminal_at=? WHERE id='A1'", (f.ts(),))
    reject("terminal Attempt cannot reopen", lambda: f.execute("UPDATE attempt SET lifecycle='active',terminal_at='' WHERE id='A1'"))
    reject("terminal Attempt timestamp immutable", lambda: f.execute("UPDATE attempt SET terminal_at='changed' WHERE id='A1'"))

    f = build_runtime(ddl)
    reject("Repair target is exactly one typed FK target", lambda: f.execute("INSERT INTO repair_target(repair_id,task_id,attempt_id) VALUES('REP-X','T1','A1')"))

    f = build_runtime(ddl)
    def orphan_repair_target():
        f.execute("BEGIN IMMEDIATE")
        try:
            f.execute("INSERT INTO repair_target(repair_id,attempt_id) VALUES('REP-ORPHAN','A1')")
            f.execute("COMMIT")
        finally:
            if f.db.in_transaction:
                f.execute("ROLLBACK")
    reject("Repair target cannot commit without Repair", orphan_repair_target)

    f = build_runtime(ddl)
    f.execute("BEGIN IMMEDIATE"); f.execute("INSERT INTO repair_target(repair_id,attempt_id) VALUES('REP1','A1')"); f.execute("INSERT INTO repair(id,repair_code,reason,evidence_digest,created_at) VALUES('REP1','code','reason','digest',?)", (f.ts(),)); f.execute("COMMIT")
    reject("Repair typed target cannot retarget", lambda: f.execute("UPDATE repair_target SET task_id='T1',attempt_id=NULL WHERE repair_id='REP1'"))

    f = build_runtime(ddl)
    f.execute("INSERT INTO task_hold(id,task_id,ordinal,kind,reason,evidence_digest,created_at) VALUES('H1','T1',1,'operator','r','d',?)", (f.ts(),))
    reject("operator Hold cannot acquire blocked-on Task child", lambda: f.execute("INSERT INTO task_hold_blocked_on_task(hold_id,blocked_on_task_id) VALUES('H1','T1')"))
    reject("TaskHold evidence cannot retarget", lambda: f.execute("UPDATE task_hold SET task_id='T1',ordinal=2 WHERE id='H1'"))

    f = Fixture(ddl); f.core(); f.execute("UPDATE plan SET lifecycle='abandoned',terminal_at=? WHERE id='PL1'", (f.ts(),))
    reject("terminal Plan cannot accept a new Attempt", lambda: f.execute("INSERT INTO attempt(id,plan_id,ordinal,worker_harness_ref,session_adapter_ref,created_at) VALUES('A2','PL1',2,'h','herdr',?)", (f.ts(),)))

    f = Fixture(ddl); f.core()
    reject("one active Plan per Task", lambda: f.execute("INSERT INTO plan(id,task_id,ordinal,lineage_kind,intent,judgment,basis,brief,brief_digest,workspace_binding_id,policy_revision_id,created_at) VALUES('PLX','T1',2,'root','execute','bounded','b','b','d','W1','POL1',?)", (f.ts(),)))
    reject("one active Attempt per Plan", lambda: f.execute("INSERT INTO attempt(id,plan_id,ordinal,worker_harness_ref,session_adapter_ref,created_at) VALUES('AX','PL1',2,'h','herdr',?)", (f.ts(),)))

    f = Fixture(ddl); f.core(); f.execute("UPDATE attempt SET lifecycle='failed',terminal_at=? WHERE id='A1'", (f.ts(),)); f.op("O-WCT", "worktree-create", "builtin/git-worktree", "worktree", "WTX")
    reject("terminal Attempt cannot prepare WorktreeCreate child", lambda: f.execute("INSERT INTO worktree_create_operation(operation_id,attempt_id,binding_id,requested_path,basis_revision,expected_common_git_dir,expected_lock_reason) VALUES('O-WCT','A1','WTX','/tmp/x','rev0','/repo/.git','hand:v1:WTX')"))

    # Proven no-effect WorktreeCreate may be replaced on the same still-current Attempt.
    f = Fixture(ddl); f.core()
    f.op("O-WC-NO", "worktree-create", "builtin/git-worktree", "worktree", "WT-NO")
    f.execute("INSERT INTO worktree_create_operation(operation_id,attempt_id,binding_id,requested_path,basis_revision,expected_common_git_dir,expected_lock_reason) VALUES('O-WC-NO','A1','WT-NO','/tmp/no','rev0','/repo/.git','hand:v1:WT-NO')")
    f.claim("O-WC-NO", "worktree", "WT-NO"); f.transition("O-WC-NO", "submitted"); f.transition("O-WC-NO", "no-effect")
    f.op("O-WC-RETRY", "worktree-create", "builtin/git-worktree", "worktree", "WT-YES")
    f.execute("INSERT INTO worktree_create_operation(operation_id,attempt_id,binding_id,requested_path,basis_revision,expected_common_git_dir,expected_lock_reason) VALUES('O-WC-RETRY','A1','WT-YES','/tmp/yes','rev0','/repo/.git','hand:v1:WT-YES')")
    f.claim("O-WC-RETRY", "worktree", "WT-YES")
    passed.append("same-Attempt WorktreeCreate replacement after proven no-effect: accepted")

    # Static schema vocabulary/shape assertions.
    db = open_fresh(ddl)
    schema_text = "\n".join(r[0] for r in db.execute("SELECT sql FROM sqlite_schema WHERE sql IS NOT NULL"))
    lowered = schema_text.lower()
    for forbidden in ("executorsignal", "treehouse", "isolationbinding", "isolation_adapter_ref", "supervisor_session", "conversation_id", "owner_kind", "owner_id", "repair_pending"):
        assert forbidden not in lowered, forbidden
    assert not re_search_word(lowered, "send"), "canonical schema contains semantic send"
    task_cols = {r[1] for r in db.execute("PRAGMA table_info(task)")}
    input_cols = {r[1] for r in db.execute("PRAGMA table_info(worker_input)")}
    assert "held" not in task_cols
    assert not ({"pending", "handled", "current", "cursor"} & input_cols)
    passed.append("forbidden legacy vocabulary/mutable shortcuts absent")

    assert db.execute("PRAGMA foreign_key_check").fetchall() == []
    assert db.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
    return passed


def terminal_task_fixture(ddl: str, *, second_task: bool = False) -> Fixture:
    f = Fixture(ddl)
    f.core(task2=second_task)
    f.execute("UPDATE attempt SET lifecycle='completed',terminal_at=? WHERE id='A1'", (f.ts(),))
    f.execute("UPDATE plan SET lifecycle='satisfied',terminal_at=? WHERE id='PL1'", (f.ts(),))
    f.execute("UPDATE task SET lifecycle='satisfied',terminal_at=? WHERE id='T1'", (f.ts(),))
    return f


def insert_task_archive(f: Fixture) -> None:
    f.execute(
        """INSERT INTO task_archive(task_id,actor_kind,actor_ref,archived_at,reason,evidence_digest)
           VALUES('T1','operator','operator-1',?,'completed and reconciled',?)""",
        (f.ts(), "a" * 64),
    )


def task_archive_proof(ddl: str) -> list[str]:
    passed: list[str] = []

    def reject(name, f):
        passed.append(expect_integrity_error(name, lambda: insert_task_archive(f)))
        assert f.execute("SELECT count(*) FROM task_archive").fetchone()[0] == 0

    f = Fixture(ddl); f.core()
    reject("active Task cannot archive", f)

    f = Fixture(ddl); f.core(); f.execute("UPDATE task SET lifecycle='abandoned',terminal_at=? WHERE id='T1'", (f.ts(),))
    reject("active Plan cannot archive", f)

    f = terminal_task_fixture(ddl)
    f.op("O-OPEN", "publication", "publisher", "publication", "ART-OPEN", attempt=None)
    reject("unresolved external operation blocks archive", f)

    f = terminal_task_fixture(ddl)
    f.execute("INSERT INTO task_hold(id,task_id,ordinal,kind,reason,evidence_digest,created_at) VALUES('H1','T1',1,'operator','wait','hold',?)", (f.ts(),))
    reject("open TaskHold blocks archive", f)

    f = terminal_task_fixture(ddl, second_task=True)
    f.execute("INSERT INTO task_hold(id,task_id,ordinal,kind,reason,evidence_digest,created_at) VALUES('H2','T2',1,'blocked','wait for T1','hold',?)", (f.ts(),))
    f.execute("INSERT INTO task_hold_blocked_on_task(hold_id,blocked_on_task_id) VALUES('H2','T1')")
    reject("inbound open TaskHold blocks archive", f)

    f = build_runtime(ddl, pending=False)
    f.execute("UPDATE attempt SET lifecycle='completed',terminal_at=? WHERE id='A1'", (f.ts(),))
    f.execute("UPDATE plan SET lifecycle='satisfied',terminal_at=? WHERE id='PL1'", (f.ts(),))
    f.execute("UPDATE task SET lifecycle='satisfied',terminal_at=? WHERE id='T1'", (f.ts(),))
    reject("open execution resources block archive", f)

    f = terminal_task_fixture(ddl)
    f.execute("INSERT INTO worker_report(id,attempt_id,source_prefix_digest,source_end_offset,report_state,note,created_at) VALUES('R1','A1','prefix',1,'working','historical progress',?)", (f.ts(),))
    insert_task_archive(f)
    assert f.execute("SELECT count(*) FROM task_archive WHERE task_id='T1'").fetchone()[0] == 1
    assert f.execute("SELECT count(*) FROM worker_report WHERE id='R1'").fetchone()[0] == 1
    passed.append("historical unacknowledged working WorkerReport does not block archive")

    for report_state in ("paused", "blocked", "needs-decision", "done", "failed"):
        f = terminal_task_fixture(ddl)
        f.execute(
            "INSERT INTO worker_report(id,attempt_id,source_prefix_digest,source_end_offset,report_state,note,created_at) VALUES('R1','A1','prefix',1,?,'review',?)",
            (report_state, f.ts()),
        )
        reject(f"unacknowledged {report_state} WorkerReport blocks archive", f)

    f = terminal_task_fixture(ddl)
    f.execute("INSERT INTO decision(id,task_id,scope_kind,question,created_at) VALUES('D1','T1','task','choose',?)", (f.ts(),))
    reject("open Decision blocks archive", f)

    f = terminal_task_fixture(ddl)
    f.execute("BEGIN IMMEDIATE")
    f.execute("INSERT INTO repair_target(repair_id,task_id) VALUES('REP1','T1')")
    f.execute("INSERT INTO repair(id,repair_code,reason,evidence_digest,created_at) VALUES('REP1','task-check','inspect','repair',?)", (f.ts(),))
    f.execute("COMMIT")
    reject("open Repair blocks archive", f)

    def reject_values(name, actor_ref, archived_at, reason, evidence_digest):
        f = terminal_task_fixture(ddl)
        passed.append(expect_integrity_error(
            name,
            lambda: f.execute(
                "INSERT INTO task_archive(task_id,actor_kind,actor_ref,archived_at,reason,evidence_digest) VALUES('T1','operator',?,?,?,?)",
                (actor_ref, archived_at, reason, evidence_digest),
            ),
        ))
        assert f.execute("SELECT count(*) FROM task_archive").fetchone()[0] == 0

    reject_values(
        "NUL-tailed Task archive actor reference cannot exceed byte bound",
        "x\x00" + "x" * 256, T0, "reason", "a" * 64,
    )
    reject_values(
        "NUL-tailed Task archive time cannot exceed byte bound",
        "operator-1", "x\x00" + "x" * 64, "reason", "a" * 64,
    )
    reject_values(
        "NUL-tailed Task archive reason cannot exceed byte bound",
        "operator-1", T0, "x\x00" + "x" * 1024, "a" * 64,
    )
    reject_values(
        "NUL-tailed Task archive evidence is not an exact SHA-256 digest",
        "operator-1", T0, "reason", "a" * 64 + "\x00junk",
    )
    reject_values(
        "NUL-terminated 64-byte Task archive evidence is not an exact SHA-256 digest",
        "operator-1", T0, "reason", "a" * 63 + "\x00",
    )
    reject_values(
        "NUL-hidden suffix in 64-byte Task archive evidence is not an exact SHA-256 digest",
        "operator-1", T0, "reason", "a" * 62 + "\x00z",
    )

    f = terminal_task_fixture(ddl)
    passed.append(expect_integrity_error(
        "archive evidence digest must be exact lowercase SHA-256",
        lambda: f.execute(
            "INSERT INTO task_archive(task_id,actor_kind,actor_ref,archived_at,reason,evidence_digest) VALUES('T1','operator','operator-1',?,'reason','BAD')",
            (f.ts(),),
        ),
    ))

    f = terminal_task_fixture(ddl)
    insert_task_archive(f)
    passed.append(expect_integrity_error(
        "conflicting duplicate Task archive",
        lambda: f.execute(
            "INSERT INTO task_archive(task_id,actor_kind,actor_ref,archived_at,reason,evidence_digest) VALUES('T1','supervisor','supervisor-2',?,'conflict',?)",
            (f.ts(), "b" * 64),
        ),
    ))
    passed.append(expect_integrity_error(
        "Task archive fact cannot update",
        lambda: f.execute("UPDATE task_archive SET reason='changed' WHERE task_id='T1'"),
    ))
    passed.append(expect_integrity_error(
        "Task archive fact cannot delete",
        lambda: f.execute("DELETE FROM task_archive WHERE task_id='T1'"),
    ))
    assert f.execute("SELECT actor_ref,reason FROM task_archive WHERE task_id='T1'").fetchone() == (
        "operator-1", "completed and reconciled"
    )

    f.execute("INSERT INTO worker_report(id,attempt_id,source_prefix_digest,source_end_offset,report_state,note,created_at) VALUES('R-LATE','A1','prefix-late',2,'failed','late evidence',?)", (f.ts(),))
    assert f.execute("SELECT count(*) FROM worker_report WHERE id='R-LATE'").fetchone()[0] == 1
    assert f.execute("SELECT lifecycle FROM task WHERE id='T1'").fetchone()[0] == "satisfied"
    assert f.execute("SELECT count(*) FROM task_archive WHERE task_id='T1'").fetchone()[0] == 1
    passed.append("handling-worthy evidence after archive remains visible without lifecycle reopen")

    assert f.db.execute("PRAGMA foreign_key_check").fetchall() == []
    assert f.db.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
    return passed


def re_search_word(text: str, word: str) -> bool:
    import re
    return re.search(rf"\b{re.escape(word)}\b", text, re.IGNORECASE) is not None


def explain(db: sqlite3.Connection, sql: str, params=()) -> str:
    return " | ".join(str(r[3]) for r in db.execute("EXPLAIN QUERY PLAN " + sql, params))


def worker_report_tail_proof(ddl: str) -> list[str]:
    f = build_runtime(ddl)
    passed: list[str] = []

    def current(attempt_id: str, executor_binding_id: str) -> bool:
        if executor_binding_id:
            row = f.execute(
                """SELECT EXISTS(
                       SELECT 1
                       FROM executor_binding e
                       JOIN attempt a ON a.id=e.attempt_id AND a.lifecycle='active' AND a.terminal_at=''
                       JOIN plan p ON p.id=a.plan_id AND p.lifecycle='active' AND p.terminal_at=''
                       JOIN task t ON t.id=p.task_id AND t.lifecycle='active' AND t.terminal_at=''
                       JOIN project project_current ON project_current.id=t.project_id AND project_current.retired_at=''
                       WHERE e.id=? AND e.attempt_id=?
                         AND NOT EXISTS (SELECT 1 FROM executor_binding_termination x WHERE x.executor_binding_id=e.id)
                   )""",
                (executor_binding_id, attempt_id),
            ).fetchone()
        else:
            row = f.execute(
                """SELECT EXISTS(
                       SELECT 1
                       FROM attempt a
                       JOIN plan p ON p.id=a.plan_id AND p.lifecycle='active' AND p.terminal_at=''
                       JOIN task t ON t.id=p.task_id AND t.lifecycle='active' AND t.terminal_at=''
                       JOIN project project_current ON project_current.id=t.project_id AND project_current.retired_at=''
                       WHERE a.id=? AND a.lifecycle='active' AND a.terminal_at=''
                   )""",
                (attempt_id,),
            ).fetchone()
        return row == (1,)

    def tail(attempt_id: str):
        return f.execute(
            """SELECT id,source_prefix_digest,source_end_offset
               FROM worker_report
               WHERE attempt_id=?
               ORDER BY source_end_offset DESC,id
               LIMIT 1""",
            (attempt_id,),
        ).fetchone()

    def ingest(
        report_id: str,
        digest: str,
        offset: int,
        predecessor,
        *,
        attempt_id: str = "A1",
        executor_binding_id: str = "E1",
        state: str = "working",
        note: str = "report",
    ):
        f.execute("BEGIN IMMEDIATE")
        try:
            existing = f.execute(
                """SELECT id,attempt_id,coalesce(executor_binding_id,''),source_prefix_digest,
                          source_end_offset,report_state,note
                   FROM worker_report
                   WHERE id=? OR (attempt_id=? AND source_prefix_digest=?)""",
                (report_id, attempt_id, digest),
            ).fetchone()
            wanted = (report_id, attempt_id, executor_binding_id, digest, offset, state, note)
            if existing is not None:
                if existing != wanted:
                    raise sqlite3.IntegrityError("exact WorkerReport replay conflicts")
                f.execute("COMMIT")
                return existing
            if not current(attempt_id, executor_binding_id):
                raise sqlite3.IntegrityError("WorkerReport source ownership is not current")
            relational_tail = tail(attempt_id)
            if relational_tail != predecessor:
                raise sqlite3.IntegrityError("WorkerReport predecessor is not the exact relational tail")
            if predecessor is not None and offset <= predecessor[2]:
                raise sqlite3.IntegrityError("WorkerReport source offset does not strictly append")
            f.execute(
                """INSERT INTO worker_report
                   (id,attempt_id,executor_binding_id,source_prefix_digest,source_end_offset,
                    report_state,note,created_at)
                   VALUES(?,?,?,?,?,?,?,?)""",
                (report_id, attempt_id, executor_binding_id or None, digest, offset, state, note, f.ts()),
            )
            f.execute("COMMIT")
            return wanted
        except Exception:
            f.execute("ROLLBACK")
            raise

    def reject(label: str, fn) -> None:
        try:
            fn()
        except sqlite3.IntegrityError:
            passed.append(label)
            return
        raise AssertionError(f"{label}: expected refusal")

    def witness(report, predecessor, *, state="working", note="report"):
        return {
            "id": report[0],
            "attempt_id": "A1",
            "executor_binding_id": "E1",
            "digest": report[1],
            "offset": report[2],
            "state": state,
            "note": note,
            "predecessor": predecessor,
        }

    def full_replay(witnesses) -> None:
        f.execute("BEGIN IMMEDIATE")
        try:
            predecessor = None
            wanted = []
            for i, item in enumerate(witnesses):
                if item["predecessor"] != predecessor:
                    raise sqlite3.IntegrityError(
                        f"full replay witness {i} does not continue its exact predecessor"
                    )
                if predecessor is not None and item["offset"] <= predecessor[2]:
                    raise sqlite3.IntegrityError(
                        f"full replay witness {i} does not strictly append"
                    )
                predecessor = (item["id"], item["digest"], item["offset"])
                wanted.append(
                    (
                        item["id"],
                        item["attempt_id"],
                        item["executor_binding_id"],
                        item["digest"],
                        item["offset"],
                        item["state"],
                        item["note"],
                    )
                )

            existing = f.execute(
                """SELECT id,attempt_id,coalesce(executor_binding_id,''),source_prefix_digest,
                          source_end_offset,report_state,note
                   FROM worker_report
                   WHERE attempt_id='A1'
                   ORDER BY source_end_offset,id"""
            ).fetchall()
            shared = min(len(existing), len(wanted))
            for i in range(shared):
                if existing[i] != wanted[i]:
                    raise sqlite3.IntegrityError(
                        f"full replay differs at WorkerReport {i}"
                    )
            if len(existing) > len(wanted):
                raise sqlite3.IntegrityError(
                    "full replay truncates immutable relational history"
                )

            relational_tail = None
            if existing:
                relational_tail = (existing[-1][0], existing[-1][3], existing[-1][4])
            if len(wanted) > len(existing):
                if witnesses[len(existing)]["predecessor"] != relational_tail:
                    raise sqlite3.IntegrityError(
                        "full replay suffix does not continue the relational tail"
                    )
                for item in witnesses[len(existing) :]:
                    if not current(item["attempt_id"], item["executor_binding_id"]):
                        raise sqlite3.IntegrityError(
                            "full replay source ownership is not current"
                        )
                    f.execute(
                        """INSERT INTO worker_report
                           (id,attempt_id,executor_binding_id,source_prefix_digest,source_end_offset,
                            report_state,note,created_at)
                           VALUES(?,?,?,?,?,?,?,?)""",
                        (
                            item["id"],
                            item["attempt_id"],
                            item["executor_binding_id"],
                            item["digest"],
                            item["offset"],
                            item["state"],
                            item["note"],
                            f.ts(),
                        ),
                    )
            f.execute("COMMIT")
        except Exception:
            f.execute("ROLLBACK")
            raise

    r1 = ("R1", "prefix-r1", 10)
    r2 = ("R2", "prefix-r2", 20)
    r3 = ("R3", "prefix-r3", 30)
    ingest(*r1, None, note="initial")
    passed.append("initial WorkerReport establishes the only empty-history root")
    ingest(*r1, None, note="initial")
    assert f.execute("SELECT count(*) FROM worker_report WHERE attempt_id='A1'").fetchone() == (1,)
    passed.append("exact WorkerReport replay creates no duplicate fact")
    ingest(*r2, r1, note="append")
    ingest(*r3, r2, note="multiple")
    assert tail("A1") == r3
    passed.append("strict append and multiple records preserve one exact relational tail")

    reject(
        "restored R1 checkpoint cannot authorize a distinct-offset rollback fork",
        lambda: ingest("R-FORK", "prefix-fork", 40, r1, state="failed", note="fork"),
    )
    reject(
        "equal source boundary cannot carry a second immutable prefix",
        lambda: f.execute(
            """INSERT INTO worker_report
               (id,attempt_id,executor_binding_id,source_prefix_digest,source_end_offset,
                report_state,note,created_at)
               VALUES('R-EQUAL','A1','E1','prefix-equal',30,'failed','equal',?)""",
            (f.ts(),),
        ),
    )
    reject(
        "different source boundary still requires the exact current predecessor",
        lambda: ingest("R-DIFFERENT", "prefix-different", 41, r2, note="stale predecessor"),
    )

    w1 = witness(r1, None, note="initial")
    w2 = witness(r2, r1, note="append")
    w3 = witness(r3, r2, note="multiple")
    full_replay([w1, w2, w3])
    assert f.execute("SELECT count(*) FROM worker_report WHERE attempt_id='A1'").fetchone() == (3,)
    r4 = ("R4", "prefix-r4", 40)
    w4 = witness(r4, r3, state="paused", note="recovered suffix")
    full_replay([w1, w2, w3, w4])
    assert tail("A1") == r4
    passed.append("checkpoint loss or corruption converges through exact full replay and proven suffix insertion")
    reject(
        "truncated full replay contradicts immutable relational history",
        lambda: full_replay([w1, w2]),
    )
    r2_changed = ("R2-CHANGED", "prefix-r2-changed", 20)
    r3_changed = ("R3-CHANGED", "prefix-r3-changed", 30)
    rewritten = [
        w1,
        witness(r2_changed, r1, state="failed", note="changed history"),
        witness(r3_changed, r2_changed, note="changed successor"),
    ]
    reject(
        "changed historical prefix contradicts immutable relational history",
        lambda: full_replay(rewritten),
    )

    stale_attempt = build_runtime(ddl)
    stale_attempt.execute(
        "UPDATE attempt SET lifecycle='failed',terminal_at=? WHERE id='A1'",
        (stale_attempt.ts(),),
    )
    original = f
    f = stale_attempt
    reject(
        "stale Attempt cannot append WorkerReport source evidence",
        lambda: ingest("R-STALE-A", "prefix-stale-a", 10, None, executor_binding_id=""),
    )
    stale_executor = build_runtime(ddl)
    stale_executor.execute(
        """INSERT INTO executor_binding_termination
           (executor_binding_id,terminal_kind,observed_at,evidence_digest)
           VALUES('E1','failed',?,'executor-terminal')""",
        (stale_executor.ts(),),
    )
    f = stale_executor
    reject(
        "stale ExecutorBinding cannot append WorkerReport source evidence",
        lambda: ingest("R-STALE-E", "prefix-stale-e", 10, None),
    )
    f = original

    predecessor = r4
    for i in range(5, 260):
        report = (f"R{i}", f"prefix-r{i}", i * 10)
        ingest(*report, predecessor, note="history")
        predecessor = report
    appended = ("R260", "prefix-r260", 2600)
    ingest(*appended, predecessor, state="done", note="small append")
    assert tail("A1") == appended
    large_plan = explain(
        f.db,
        """SELECT id,source_prefix_digest,source_end_offset
           FROM worker_report
           WHERE attempt_id=?
           ORDER BY source_end_offset DESC,id
           LIMIT 1""",
        ("A1",),
    )
    assert "worker_report_attempt_source_order" in large_plan, large_plan
    assert "TEMP B-TREE" not in large_plan, large_plan
    passed.append("large history accepts one small append through one indexed tail lookup")
    return passed


def query_plan_proof(ddl: str) -> dict[str, str]:
    f = build_runtime(ddl)
    f.execute("INSERT INTO worker_report(id,attempt_id,executor_binding_id,source_prefix_digest,source_end_offset,report_state,note,created_at) VALUES('R1','A1','E1','p',1,'working','n',?)", (f.ts(),))
    f.execute("INSERT INTO task_hold(id,task_id,ordinal,kind,reason,evidence_digest,created_at) VALUES('H1','T1',1,'operator','r','d',?)", (f.ts(),))
    f.execute("INSERT INTO attempt_backoff(id,attempt_id,ordinal,reason,not_before,evidence_digest,created_at) VALUES('B1','A1',1,'rate-limit','later','d',?)", (f.ts(),))
    f.execute("BEGIN IMMEDIATE"); f.execute("INSERT INTO repair_target(repair_id,executor_binding_id) VALUES('REP1','E1')"); f.execute("INSERT INTO repair(id,repair_code,reason,evidence_digest,created_at) VALUES('REP1','code','r','d',?)", (f.ts(),)); f.execute("COMMIT")
    f.op("O-WAKE-P", "worker-wake", "herdr", "executor-control", "E1")
    f.execute("INSERT INTO worker_wake_operation(operation_id,attempt_id,session_binding_id,executor_binding_id,pending_through_ordinal,wake_reason,doorbell_digest) VALUES('O-WAKE-P','A1','S1','E1',1,'wake','d')")
    f.claim("O-WAKE-P", "executor-control", "E1")

    checks = {
        "active_plan": ("SELECT id FROM plan WHERE task_id=? AND lifecycle='active'", ("T1",), "plan_one_active_by_task"),
        "active_attempt": ("SELECT id FROM attempt WHERE plan_id=? AND lifecycle='active'", ("PL1",), "attempt_one_active_by_plan"),
        "worker_input_order": ("SELECT id FROM worker_input WHERE executor_binding_id=? ORDER BY ordinal", ("E1",), "worker_input_current_order"),
        "unack_worker_input": ("SELECT wi.id FROM worker_input wi LEFT JOIN worker_input_acknowledgement a ON a.worker_input_id=wi.id WHERE wi.executor_binding_id=? AND a.worker_input_id IS NULL ORDER BY wi.ordinal", ("E1",), "worker_input_current_order"),
        "latest_worker_reports": ("SELECT id FROM worker_report WHERE attempt_id=? ORDER BY created_at DESC,id LIMIT 10", ("A1",), "worker_report_attempt_latest"),
        "worker_report_source_tail": ("SELECT id,source_prefix_digest,source_end_offset FROM worker_report WHERE attempt_id=? ORDER BY source_end_offset DESC,id LIMIT 1", ("A1",), "worker_report_attempt_source_order"),
        "open_holds": ("SELECT h.id FROM task_hold h LEFT JOIN task_hold_resolution r ON r.hold_id=h.id WHERE h.task_id=? AND r.hold_id IS NULL ORDER BY h.ordinal DESC", ("T1",), "task_hold_task_history"),
        "open_backoffs": ("SELECT b.id FROM attempt_backoff b LEFT JOIN attempt_backoff_resolution r ON r.backoff_id=b.id WHERE b.attempt_id=? AND r.backoff_id IS NULL ORDER BY b.ordinal DESC", ("A1",), "attempt_backoff_attempt_history"),
        "open_repairs_by_executor": ("SELECT r.id FROM repair_target rt JOIN repair r ON r.id=rt.repair_id LEFT JOIN repair_resolution rr ON rr.repair_id=r.id WHERE rt.executor_binding_id=? AND rr.repair_id IS NULL", ("E1",), "repair_target_executor"),
        "unresolved_operations": ("SELECT id FROM external_operation WHERE project_id=? AND kind='worker-wake' AND state IN ('prepared','submitted','uncertain') ORDER BY created_at", ("P1",), "external_operation_unresolved"),
        "scope_claim": ("SELECT operation_id FROM operation_scope_claim WHERE scope_kind=? AND scope_key=?", ("executor-control", "E1"), "operation_scope_claim_lookup"),
        "attempt_fallback_history": ("SELECT ordinal,rejection_reason FROM attempt_fallback_step WHERE attempt_id=? AND ordinal>? ORDER BY ordinal LIMIT 20", ("A1", 0), "sqlite_autoindex_attempt_fallback_step_1"),
        "task_archive_lookup": ("SELECT task_id FROM task_archive WHERE task_id=?", ("T1",), "sqlite_autoindex_task_archive_1"),
    }
    out = {}
    for name, (sql, params, expected_index) in checks.items():
        plan = explain(f.db, sql, params)
        if expected_index not in plan:
            raise AssertionError(f"{name}: expected {expected_index}; plan={plan}")
        out[name] = plan
    return out


def cutover_target_proof(ddl: str, ddl_sha: str, fingerprint: str) -> dict:
    f = Fixture(ddl)
    f.execute("INSERT INTO fleet(singleton,fleet_id,created_at) VALUES(1,'F1',?)", (f.ts(),))
    f.execute("INSERT INTO project(id,fleet_id,ordinal,display_name,created_at) VALUES('P1','F1',1,'imported-project',?)", (f.ts(),))
    f.execute("INSERT INTO workspace_binding(id,project_id,ordinal,repository_locator,repository_identity_digest,common_git_dir,physical_identity_digest,revision,established_at) VALUES('W1','P1',1,'repo://import','repo-d','/repo/.git','phys-import','rev0',?)", (f.ts(),))
    f.execute("INSERT INTO policy_revision(id,project_id,ordinal,policy_digest,created_at) VALUES('POL1','P1',1,'policy-d',?)", (f.ts(),))
    f.execute(
        """INSERT INTO legacy_import
           (id,fleet_id,source_user_version,source_db_sha256,archive_db_sha256,manifest_sha256,
            target_ddl_sha256,target_schema_fingerprint,imported_at)
           VALUES('IMP1','F1',18,'source-sha','source-sha','manifest-sha',?,?,?)""",
        (ddl_sha, fingerprint, f.ts()),
    )
    f.execute("INSERT INTO legacy_import_project(import_id,project_id,workspace_binding_id,policy_revision_id,evidence_digest) VALUES('IMP1','P1','W1','POL1','import-evidence')")
    zero_tables = [
        "task", "plan", "attempt", "attempt_fallback_step", "attempt_worktree_binding", "session_binding", "executor_binding",
        "worker_input", "worker_input_acknowledgement", "worker_wake_operation", "worker_report", "task_archive",
        "external_operation", "terminal_receipt", "artifact",
    ]
    nonzero = {t: f.db.execute(f"SELECT count(*) FROM {t}").fetchone()[0] for t in zero_tables}
    assert all(v == 0 for v in nonzero.values()), nonzero
    assert f.db.execute("PRAGMA user_version").fetchone()[0] == 19
    assert f.db.execute("PRAGMA foreign_key_check").fetchall() == []
    assert f.db.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
    return {"source_user_version": 18, "target_user_version": 19, "fabricated_execution_input_effect_rows": 0}


def routing_provenance_proof(ddl: str) -> list[str]:
    evidence = []
    def seeded():
        f = Fixture(ddl)
        f.core()
        return f
    def fallback(f, ordinal=1, reason='quota-exhausted', attempt='A1', digest='a'*64):
        return f.execute('''INSERT INTO attempt_fallback_step(attempt_id,ordinal,rejected_profile_ref,
            rejected_harness_ref,rejected_model_ref,rejected_effort_ref,rejection_reason,observation_digest,observed_at)
            VALUES(?,?,'approved-profile','rejected-harness','model-a','medium',?,?,?)''',
            (attempt,ordinal,reason,digest,f.ts()))
    f = seeded()
    assert f.execute('SELECT profile_override,harness_override,model_override,effort_override FROM attempt').fetchone() == (None,)*4
    assert f.execute('SELECT COUNT(*) FROM attempt_fallback_step').fetchone() == (0,)
    evidence.append('first candidate: absent overrides, explicit final tuple and zero fallback rows')
    for field in ['profile_override','harness_override','model_override','effort_override']:
        evidence.append(expect_integrity_error('override immutable '+field, lambda field=field: f.execute(f"UPDATE attempt SET {field}='new' WHERE id='A1'")))
    reasons = ['harness-unavailable','model-unavailable','quota-exhausted','capability-unavailable','combination-unsupported']
    for i,reason in enumerate(reasons,1):
        fallback(f,i,reason)
        evidence.append('positive rejection '+reason)
    assert f.execute('SELECT ordinal,rejection_reason FROM attempt_fallback_step ORDER BY ordinal').fetchall() == list(enumerate(reasons,1))
    assert f.execute("SELECT worker_harness_ref,model_ref FROM attempt WHERE id='A1'").fetchone() == ('worker-harness','model')
    evidence.append('rejected chain never substitutes for final selected tuple')
    evidence.append(expect_integrity_error('unknown is not unavailable',lambda:fallback(f,6,'unknown')))
    evidence.append(expect_integrity_error('ordinal gap',lambda:fallback(f,7)))
    evidence.append(expect_integrity_error('duplicate ordinal',lambda:fallback(f,5)))
    evidence.append(expect_integrity_error('exact Attempt FK',lambda:fallback(f,1,attempt='missing')))
    evidence.append(expect_integrity_error('bounded lowercase digest',lambda:fallback(f,6,digest='G'*64)))
    evidence.append(expect_integrity_error('fallback immutable',lambda:f.execute("UPDATE attempt_fallback_step SET rejection_reason='harness-unavailable' WHERE ordinal=1")))
    evidence.append(expect_integrity_error('fallback nondeletable',lambda:f.execute('DELETE FROM attempt_fallback_step WHERE ordinal=1')))
    f = seeded()
    f.execute("UPDATE attempt SET lifecycle='failed',terminal_at=? WHERE id='A1'",(f.ts(),))
    evidence.append(expect_integrity_error('terminal Attempt refuses late fallback',lambda:fallback(f)))
    insert_attempt = '''INSERT INTO attempt(id,plan_id,ordinal,worker_harness_ref,worker_profile_ref,model_ref,
        effort_ref,session_adapter_ref,created_at,profile_override,harness_override,model_override,effort_override)
        VALUES('A2','PL1',2,'selected-harness','selected-profile','selected-model','high','herdr',?,?,?,?,?)'''
    f.execute('BEGIN IMMEDIATE')
    f.execute(insert_attempt,(f.ts(),'requested-profile','requested-harness','requested-model','low'))
    fallback(f,1,attempt='A2')
    evidence.append(expect_integrity_error('invalid chain refuses',lambda:fallback(f,2,'unknown',attempt='A2')))
    f.execute('ROLLBACK')
    assert f.execute("SELECT COUNT(*) FROM attempt WHERE id='A2'").fetchone() == (0,)
    assert f.execute('SELECT COUNT(*) FROM attempt_fallback_step').fetchone() == (0,)
    evidence.append('whole Attempt plus chain rollback is atomic')
    f.execute('BEGIN IMMEDIATE')
    f.execute(insert_attempt,(f.ts(),'requested-profile','requested-harness','requested-model','low'))
    fallback(f,1,attempt='A2')
    f.execute('COMMIT')
    assert f.execute("SELECT profile_override,harness_override,model_override,effort_override FROM attempt WHERE id='A2'").fetchone() == ('requested-profile','requested-harness','requested-model','low')
    assert f.execute("SELECT worker_profile_ref,worker_harness_ref,model_ref,effort_ref FROM attempt WHERE id='A2'").fetchone() == ('selected-profile','selected-harness','selected-model','high')
    evidence.append('request and final fields are distinct immutable history on retry')
    for field in ['profile_override','harness_override','model_override','effort_override']:
        evidence.append(expect_integrity_error('override cannot become absent '+field,lambda field=field:f.execute(f"UPDATE attempt SET {field}=NULL WHERE id='A2'")))
    f = seeded()
    f.op('O-WC','worktree-create','builtin/git-worktree','worktree','candidate-path')
    evidence.append(expect_integrity_error('no fallback after an Attempt effect',lambda:fallback(f)))
    for field,value in [('profile_override',''),('harness_override',''),('model_override','x'*513),('effort_override','x'*513)]:
        f = seeded()
        f.execute("UPDATE attempt SET lifecycle='failed',terminal_at=? WHERE id='A1'",(f.ts(),))
        values = dict(profile_override=None,harness_override=None,model_override=None,effort_override=None)
        values[field] = value
        evidence.append(expect_integrity_error('invalid override '+field,lambda:f.execute(insert_attempt,(f.ts(),*values.values()))))
    f = seeded()
    f.execute("UPDATE attempt SET lifecycle='failed',terminal_at=? WHERE id='A1'",(f.ts(),))
    f.execute(insert_attempt,(f.ts(),None,None,'',''))
    assert f.execute("SELECT model_override,effort_override FROM attempt WHERE id='A2'").fetchone() == ('','')
    evidence.append('supported explicit empty model/effort distinct from absent; runtime validation still required')
    assert f.execute('PRAGMA foreign_key_check').fetchall() == []
    assert f.execute('PRAGMA integrity_check').fetchone() == ('ok',)
    return evidence


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("ddl", nargs="?", default=str(Path(__file__).with_name("v19-v4.sql")))
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()
    path = Path(args.ddl)
    raw = path.read_bytes()
    ddl = raw.decode("utf-8")

    fresh = open_fresh(ddl)
    fk = fresh.execute("PRAGMA foreign_key_check").fetchall()
    integrity = fresh.execute("PRAGMA integrity_check").fetchone()[0]
    assert fk == []
    assert integrity == "ok"
    ddl_sha = sha256_bytes(raw)
    fingerprint = schema_fingerprint(fresh)
    counts = object_counts(fresh)
    assert ddl_sha == EXPECTED_DDL_SHA256, (ddl_sha, EXPECTED_DDL_SHA256)
    assert fingerprint == EXPECTED_SCHEMA_FINGERPRINT, (fingerprint, EXPECTED_SCHEMA_FINGERPRINT)
    assert all(counts[key] == value for key, value in EXPECTED_OBJECT_COUNTS.items()), (
        counts, EXPECTED_OBJECT_COUNTS
    )

    representative = representative_flow(ddl)
    adversarial = adversarial_proof(ddl)
    archive = task_archive_proof(ddl)
    worker_report_tail = worker_report_tail_proof(ddl)
    routing = routing_provenance_proof(ddl)
    query_plans = query_plan_proof(ddl)
    cutover = cutover_target_proof(ddl, ddl_sha, fingerprint)

    result = {
        "ddl_path": str(path),
        "byte_count": len(raw),
        "ddl_sha256": ddl_sha,
        "schema_fingerprint": fingerprint,
        "sqlite_version": sqlite3.sqlite_version,
        "user_version": 19,
        "object_counts": counts,
        "fresh_database": {"foreign_key_check": "empty", "integrity_check": integrity},
        "representative_flow": representative,
        "adversarial_tests_passed": len(adversarial),
        "adversarial_evidence": adversarial,
        "task_archive_tests_passed": len(archive),
        "task_archive_evidence": archive,
        "worker_report_tail_tests_passed": len(worker_report_tail),
        "worker_report_tail_evidence": worker_report_tail,
        "routing_provenance_tests_passed": len(routing),
        "routing_provenance_evidence": routing,
        "query_plan_checks_passed": len(query_plans),
        "query_plans": query_plans,
        "cutover_target": cutover,
        "status": "PASS",
    }
    if args.json:
        print(json.dumps(result, indent=2, sort_keys=True))
    else:
        print("PASS canonical v19 relock proof")
        print(f"bytes={result['byte_count']}")
        print(f"ddl_sha256={ddl_sha}")
        print(f"schema_fingerprint={fingerprint}")
        print(f"objects={counts['tables']} tables / {counts['indexes']} indexes / {counts['triggers']} triggers")
        print(
            f"adversarial={len(adversarial)} worker_report_tail={len(worker_report_tail)} "
            f"query_plans={len(query_plans)} cutover=PASS"
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
