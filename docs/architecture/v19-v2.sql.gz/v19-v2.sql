-- Canonical v19 Fleet database DDL authority for atqamz/hand#344.
-- Execute only against a fresh SQLite database.
-- Schema fingerprint algorithm used by the relock proof:
--   SHA-256 of UTF-8 lines `type|name|tbl_name|sql`, sorted by (type,name),
--   from sqlite_schema where name NOT LIKE 'sqlite_%' and sql IS NOT NULL.
PRAGMA foreign_keys = ON;

CREATE TABLE fleet (
    singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
    fleet_id TEXT NOT NULL UNIQUE CHECK (length(fleet_id) > 0),
    created_at TEXT NOT NULL CHECK (length(created_at) > 0)
) STRICT;

CREATE TABLE project (
    id TEXT PRIMARY KEY CHECK (length(id) > 0),
    fleet_id TEXT NOT NULL REFERENCES fleet(fleet_id),
    ordinal INTEGER NOT NULL CHECK (ordinal > 0),
    display_name TEXT NOT NULL CHECK (length(display_name) > 0),
    created_at TEXT NOT NULL CHECK (length(created_at) > 0),
    retired_at TEXT NOT NULL DEFAULT '',
    UNIQUE (fleet_id, ordinal),
    UNIQUE (fleet_id, display_name),
    CHECK (retired_at = '' OR retired_at >= created_at)
) STRICT;

CREATE TABLE workspace_binding (
    id TEXT PRIMARY KEY CHECK (length(id) > 0),
    project_id TEXT NOT NULL REFERENCES project(id),
    ordinal INTEGER NOT NULL CHECK (ordinal > 0),
    repository_locator TEXT NOT NULL CHECK (length(repository_locator) > 0),
    repository_identity_digest TEXT NOT NULL CHECK (length(repository_identity_digest) > 0),
    common_git_dir TEXT NOT NULL CHECK (length(common_git_dir) > 0),
    physical_identity_digest TEXT NOT NULL CHECK (length(physical_identity_digest) > 0),
    revision TEXT NOT NULL CHECK (length(revision) > 0),
    established_at TEXT NOT NULL CHECK (length(established_at) > 0),
    superseded_at TEXT NOT NULL DEFAULT '',
    UNIQUE (project_id, ordinal),
    CHECK (superseded_at = '' OR superseded_at >= established_at)
) STRICT;

CREATE UNIQUE INDEX workspace_binding_one_current
ON workspace_binding(project_id) WHERE superseded_at = '';

CREATE UNIQUE INDEX workspace_binding_one_current_physical
ON workspace_binding(physical_identity_digest) WHERE superseded_at = '';

CREATE INDEX workspace_binding_project_history
ON workspace_binding(project_id, ordinal DESC);

CREATE TABLE policy_revision (
    id TEXT PRIMARY KEY CHECK (length(id) > 0),
    project_id TEXT NOT NULL REFERENCES project(id),
    ordinal INTEGER NOT NULL CHECK (ordinal > 0),
    policy_digest TEXT NOT NULL CHECK (length(policy_digest) > 0),
    worker_profile_ref TEXT NOT NULL DEFAULT '',
    qualification_policy_ref TEXT NOT NULL DEFAULT '',
    integration_policy_ref TEXT NOT NULL DEFAULT '',
    production_policy_ref TEXT NOT NULL DEFAULT '',
    publication_policy_ref TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL CHECK (length(created_at) > 0),
    superseded_at TEXT NOT NULL DEFAULT '',
    UNIQUE (project_id, ordinal),
    CHECK (superseded_at = '' OR superseded_at >= created_at)
) STRICT;

CREATE UNIQUE INDEX policy_revision_one_current
ON policy_revision(project_id) WHERE superseded_at = '';

CREATE INDEX policy_revision_project_history
ON policy_revision(project_id, ordinal DESC);

CREATE TABLE task (
    id TEXT PRIMARY KEY CHECK (length(id) > 0),
    project_id TEXT NOT NULL REFERENCES project(id),
    ordinal INTEGER NOT NULL CHECK (ordinal > 0),
    goal TEXT NOT NULL CHECK (length(goal) > 0),
    goal_digest TEXT NOT NULL CHECK (length(goal_digest) > 0),
    supersedes_task_id TEXT REFERENCES task(id),
    lifecycle TEXT NOT NULL DEFAULT 'active'
      CHECK (lifecycle IN ('active','satisfied','superseded','abandoned')),
    created_at TEXT NOT NULL CHECK (length(created_at) > 0),
    terminal_at TEXT NOT NULL DEFAULT '',
    UNIQUE (project_id, ordinal),
    UNIQUE (supersedes_task_id),
    CHECK ((lifecycle='active' AND terminal_at='') OR
           (lifecycle<>'active' AND terminal_at<>''))
) STRICT;

CREATE INDEX task_active_by_project
ON task(project_id, ordinal) WHERE lifecycle='active';

CREATE TABLE task_archive (
    task_id TEXT PRIMARY KEY REFERENCES task(id),
    actor_kind TEXT NOT NULL CHECK (actor_kind IN ('operator','supervisor')),
    actor_ref TEXT NOT NULL CHECK (
      length(CAST(actor_ref AS BLOB))>0 AND length(CAST(actor_ref AS BLOB))<=256
    ),
    archived_at TEXT NOT NULL CHECK (
      length(CAST(archived_at AS BLOB))>0 AND length(CAST(archived_at AS BLOB))<=64
    ),
    reason TEXT NOT NULL CHECK (
      length(CAST(reason AS BLOB))>0 AND length(CAST(reason AS BLOB))<=1024
    ),
    evidence_digest TEXT NOT NULL CHECK (
      length(evidence_digest)=64 AND length(CAST(evidence_digest AS BLOB))=64 AND
      evidence_digest NOT GLOB '*[^0-9a-f]*'
    )
) STRICT;

CREATE TABLE plan (
    id TEXT PRIMARY KEY CHECK (length(id) > 0),
    task_id TEXT NOT NULL REFERENCES task(id),
    ordinal INTEGER NOT NULL CHECK (ordinal > 0),
    lineage_kind TEXT NOT NULL CHECK (lineage_kind IN ('root','replan','advance')),
    predecessor_plan_id TEXT REFERENCES plan(id),
    intent TEXT NOT NULL CHECK (intent IN ('explore','execute')),
    judgment TEXT NOT NULL CHECK (judgment IN ('mechanical','bounded','substantial')),
    basis TEXT NOT NULL,
    brief TEXT NOT NULL,
    brief_digest TEXT NOT NULL CHECK (length(brief_digest) > 0),
    workspace_binding_id TEXT NOT NULL REFERENCES workspace_binding(id),
    policy_revision_id TEXT NOT NULL REFERENCES policy_revision(id),
    lifecycle TEXT NOT NULL DEFAULT 'active'
      CHECK (lifecycle IN ('active','satisfied','superseded','abandoned')),
    created_at TEXT NOT NULL CHECK (length(created_at) > 0),
    terminal_at TEXT NOT NULL DEFAULT '',
    UNIQUE (task_id, ordinal),
    UNIQUE (predecessor_plan_id),
    CHECK ((lineage_kind='root' AND predecessor_plan_id IS NULL) OR
           (lineage_kind IN ('replan','advance') AND predecessor_plan_id IS NOT NULL)),
    CHECK ((lifecycle='active' AND terminal_at='') OR
           (lifecycle<>'active' AND terminal_at<>''))
) STRICT;

CREATE UNIQUE INDEX plan_one_active_by_task
ON plan(task_id) WHERE lifecycle='active';

CREATE INDEX plan_active_by_task
ON plan(task_id, ordinal DESC) WHERE lifecycle='active';

CREATE TABLE attempt (
    id TEXT PRIMARY KEY CHECK (length(id) > 0),
    plan_id TEXT NOT NULL REFERENCES plan(id),
    ordinal INTEGER NOT NULL CHECK (ordinal > 0),
    worker_harness_ref TEXT NOT NULL CHECK (length(worker_harness_ref) > 0),
    worker_harness_version TEXT NOT NULL DEFAULT '',
    worker_profile_ref TEXT NOT NULL DEFAULT '',
    model_ref TEXT NOT NULL DEFAULT '',
    effort_ref TEXT NOT NULL DEFAULT '',
    session_adapter_ref TEXT NOT NULL CHECK (length(session_adapter_ref) > 0),
    lifecycle TEXT NOT NULL DEFAULT 'active'
      CHECK (lifecycle IN ('active','completed','failed','interrupted')),
    created_at TEXT NOT NULL CHECK (length(created_at) > 0),
    terminal_at TEXT NOT NULL DEFAULT '',
    UNIQUE (plan_id, ordinal),
    CHECK ((lifecycle='active' AND terminal_at='') OR
           (lifecycle<>'active' AND terminal_at<>''))
) STRICT;

CREATE UNIQUE INDEX attempt_one_active_by_plan
ON attempt(plan_id) WHERE lifecycle='active';

CREATE INDEX attempt_active_by_plan
ON attempt(plan_id, ordinal DESC) WHERE lifecycle='active';

CREATE TABLE external_operation (
    id TEXT PRIMARY KEY CHECK (length(id) > 0),
    kind TEXT NOT NULL CHECK (kind IN ('worktree-create','worktree-remove','session-acquire','session-release','launch','worker-wake','interrupt','executor-residual-cleanup','qualification','integration','production','publication')),
    adapter_ref TEXT NOT NULL CHECK (length(adapter_ref) > 0),
    operation_key TEXT NOT NULL CHECK (length(operation_key) > 0),
    request_digest TEXT NOT NULL CHECK (length(request_digest) > 0),
    project_id TEXT NOT NULL REFERENCES project(id),
    task_id TEXT REFERENCES task(id),
    plan_id TEXT REFERENCES plan(id),
    attempt_id TEXT REFERENCES attempt(id),
    primary_scope_kind TEXT NOT NULL CHECK (
      primary_scope_kind IN ('workspace','worktree','session','executor-control','qualification','integration','production','publication')
    ),
    primary_scope_key TEXT NOT NULL CHECK (length(primary_scope_key) > 0),
    state TEXT NOT NULL DEFAULT 'prepared'
      CHECK (state IN ('prepared','submitted','succeeded','rejected','no-effect','uncertain')),
    created_at TEXT NOT NULL CHECK (length(created_at) > 0),
    state_changed_at TEXT NOT NULL CHECK (length(state_changed_at) > 0),
    state_evidence_digest TEXT NOT NULL DEFAULT '',
    submitted_at TEXT NOT NULL DEFAULT '',
    finalized_at TEXT NOT NULL DEFAULT '',
    UNIQUE (adapter_ref, operation_key),
    CHECK (state='prepared' OR state_evidence_digest<>''),
    CHECK ((state='submitted' AND submitted_at<>'') OR state<>'submitted'),
    CHECK ((state IN ('succeeded','rejected','no-effect') AND finalized_at<>'') OR
           state NOT IN ('succeeded','rejected','no-effect'))
) STRICT;

CREATE INDEX external_operation_unresolved
ON external_operation(project_id, kind, state, created_at)
WHERE state IN ('prepared','submitted','uncertain');

CREATE INDEX external_operation_attempt
ON external_operation(attempt_id, kind, created_at DESC);

CREATE TABLE external_operation_event (
    id INTEGER PRIMARY KEY,
    operation_id TEXT NOT NULL REFERENCES external_operation(id),
    from_state TEXT NOT NULL,
    to_state TEXT NOT NULL CHECK (to_state IN ('prepared','submitted','succeeded','rejected','no-effect','uncertain')),
    observed_at TEXT NOT NULL CHECK (length(observed_at)>0),
    evidence_digest TEXT NOT NULL DEFAULT ''
) STRICT;

CREATE INDEX external_operation_event_history
ON external_operation_event(operation_id, id);

CREATE TABLE operation_scope_claim (
    operation_id TEXT NOT NULL REFERENCES external_operation(id),
    scope_kind TEXT NOT NULL CHECK (
      scope_kind IN ('workspace','worktree','session','executor-control','qualification','integration','production','publication')
    ),
    scope_key TEXT NOT NULL CHECK (length(scope_key)>0),
    created_at TEXT NOT NULL CHECK (length(created_at)>0),
    PRIMARY KEY (operation_id, scope_kind, scope_key)
) STRICT;

CREATE INDEX operation_scope_claim_lookup
ON operation_scope_claim(scope_kind, scope_key, operation_id);

CREATE TABLE worktree_create_operation (
    operation_id TEXT PRIMARY KEY REFERENCES external_operation(id),
    attempt_id TEXT NOT NULL REFERENCES attempt(id),
    binding_id TEXT NOT NULL UNIQUE CHECK (length(binding_id)>0),
    requested_path TEXT NOT NULL CHECK (length(requested_path)>0),
    basis_revision TEXT NOT NULL CHECK (length(basis_revision)>0),
    expected_common_git_dir TEXT NOT NULL CHECK (length(expected_common_git_dir)>0),
    expected_lock_reason TEXT NOT NULL CHECK (length(expected_lock_reason)>0)
) STRICT;

CREATE TABLE worktree_remove_operation (
    operation_id TEXT PRIMARY KEY REFERENCES external_operation(id),
    binding_id TEXT NOT NULL REFERENCES attempt_worktree_binding(id),
    expected_physical_identity_digest TEXT NOT NULL CHECK (length(expected_physical_identity_digest)>0),
    expected_common_git_dir TEXT NOT NULL CHECK (length(expected_common_git_dir)>0),
    expected_private_git_dir TEXT NOT NULL CHECK (length(expected_private_git_dir)>0),
    expected_lock_reason TEXT NOT NULL CHECK (length(expected_lock_reason)>0),
    expected_head_revision TEXT NOT NULL CHECK (length(expected_head_revision)>0)
) STRICT;

CREATE TABLE session_acquire_operation (
    operation_id TEXT PRIMARY KEY REFERENCES external_operation(id),
    attempt_id TEXT NOT NULL REFERENCES attempt(id),
    worktree_binding_id TEXT NOT NULL REFERENCES attempt_worktree_binding(id),
    binding_id TEXT NOT NULL UNIQUE CHECK (length(binding_id)>0),
    requested_provider_session_key TEXT NOT NULL DEFAULT ''
) STRICT;

CREATE TABLE session_release_operation (
    operation_id TEXT PRIMARY KEY REFERENCES external_operation(id),
    session_binding_id TEXT NOT NULL REFERENCES session_binding(id),
    expected_provider_session_key TEXT NOT NULL CHECK (length(expected_provider_session_key)>0)
) STRICT;

CREATE TABLE launch_operation (
    operation_id TEXT PRIMARY KEY REFERENCES external_operation(id),
    attempt_id TEXT NOT NULL REFERENCES attempt(id),
    session_binding_id TEXT NOT NULL REFERENCES session_binding(id),
    binding_id TEXT NOT NULL UNIQUE CHECK (length(binding_id)>0),
    executable TEXT NOT NULL CHECK (length(executable)>0),
    cwd TEXT NOT NULL CHECK (length(cwd)>0),
    launch_spec_digest TEXT NOT NULL CHECK (length(launch_spec_digest)>0)
) STRICT;

CREATE TABLE launch_argument (
    operation_id TEXT NOT NULL REFERENCES launch_operation(operation_id),
    ordinal INTEGER NOT NULL CHECK (ordinal >= 0),
    value TEXT NOT NULL,
    PRIMARY KEY (operation_id, ordinal)
) STRICT;

CREATE TABLE launch_environment (
    operation_id TEXT NOT NULL REFERENCES launch_operation(operation_id),
    name TEXT NOT NULL CHECK (length(name)>0),
    value_kind TEXT NOT NULL CHECK (value_kind IN ('literal','secret-ref')),
    value_material TEXT NOT NULL,
    value_digest TEXT NOT NULL CHECK (length(value_digest)>0),
    PRIMARY KEY (operation_id, name)
) STRICT;

CREATE TABLE worker_wake_operation (
    operation_id TEXT PRIMARY KEY REFERENCES external_operation(id),
    attempt_id TEXT NOT NULL REFERENCES attempt(id),
    session_binding_id TEXT NOT NULL REFERENCES session_binding(id),
    executor_binding_id TEXT NOT NULL REFERENCES executor_binding(id),
    pending_through_ordinal INTEGER NOT NULL CHECK (pending_through_ordinal > 0),
    wake_reason TEXT NOT NULL CHECK (length(wake_reason)>0 AND length(wake_reason)<=128),
    doorbell_digest TEXT NOT NULL CHECK (length(doorbell_digest)>0)
) STRICT;

CREATE TABLE interrupt_operation (
    operation_id TEXT PRIMARY KEY REFERENCES external_operation(id),
    attempt_id TEXT NOT NULL REFERENCES attempt(id),
    executor_binding_id TEXT NOT NULL REFERENCES executor_binding(id),
    reason_code TEXT NOT NULL CHECK (length(reason_code)>0 AND length(reason_code)<=128)
) STRICT;

CREATE TABLE executor_residual_cleanup_operation (
    operation_id TEXT PRIMARY KEY REFERENCES external_operation(id),
    attempt_id TEXT NOT NULL REFERENCES attempt(id),
    executor_binding_id TEXT NOT NULL REFERENCES executor_binding(id),
    residual_identity_digest TEXT NOT NULL CHECK (length(residual_identity_digest)>0)
) STRICT;

CREATE TABLE qualification_operation (
    operation_id TEXT PRIMARY KEY REFERENCES external_operation(id),
    plan_id TEXT NOT NULL REFERENCES plan(id),
    terminal_receipt_id TEXT NOT NULL REFERENCES terminal_receipt(id),
    policy_revision_id TEXT NOT NULL REFERENCES policy_revision(id)
) STRICT;

CREATE TABLE integration_operation (
    operation_id TEXT PRIMARY KEY REFERENCES external_operation(id),
    plan_id TEXT NOT NULL REFERENCES plan(id),
    terminal_receipt_id TEXT NOT NULL REFERENCES terminal_receipt(id),
    target_ref TEXT NOT NULL CHECK (length(target_ref)>0),
    expected_candidate_revision TEXT NOT NULL CHECK (length(expected_candidate_revision)>0)
) STRICT;

CREATE TABLE production_operation (
    operation_id TEXT PRIMARY KEY REFERENCES external_operation(id),
    plan_id TEXT NOT NULL REFERENCES plan(id),
    integration_receipt_id TEXT NOT NULL REFERENCES integration_receipt(operation_id),
    target_ref TEXT NOT NULL CHECK (length(target_ref)>0)
) STRICT;

CREATE TABLE publication_operation (
    operation_id TEXT PRIMARY KEY REFERENCES external_operation(id),
    artifact_id TEXT NOT NULL REFERENCES artifact(id),
    target_ref TEXT NOT NULL CHECK (length(target_ref)>0)
) STRICT;

CREATE TABLE attempt_worktree_binding (
    id TEXT PRIMARY KEY CHECK (length(id)>0),
    attempt_id TEXT NOT NULL UNIQUE REFERENCES attempt(id),
    create_operation_id TEXT NOT NULL UNIQUE REFERENCES worktree_create_operation(operation_id),
    path TEXT NOT NULL CHECK (length(path)>0),
    common_git_dir TEXT NOT NULL CHECK (length(common_git_dir)>0),
    private_git_dir TEXT NOT NULL CHECK (length(private_git_dir)>0),
    lock_reason TEXT NOT NULL CHECK (length(lock_reason)>0),
    basis_revision TEXT NOT NULL CHECK (length(basis_revision)>0),
    head_revision TEXT NOT NULL CHECK (length(head_revision)>0),
    physical_identity_digest TEXT NOT NULL CHECK (length(physical_identity_digest)>0),
    established_at TEXT NOT NULL CHECK (length(established_at)>0)
) STRICT;

CREATE INDEX attempt_worktree_binding_physical
ON attempt_worktree_binding(physical_identity_digest);

CREATE INDEX attempt_worktree_binding_path
ON attempt_worktree_binding(path);

CREATE TABLE worktree_binding_release (
    binding_id TEXT PRIMARY KEY REFERENCES attempt_worktree_binding(id),
    remove_operation_id TEXT NOT NULL UNIQUE REFERENCES worktree_remove_operation(operation_id),
    released_at TEXT NOT NULL CHECK (length(released_at)>0),
    evidence_digest TEXT NOT NULL CHECK (length(evidence_digest)>0)
) STRICT;

CREATE TABLE session_binding (
    id TEXT PRIMARY KEY CHECK (length(id)>0),
    attempt_id TEXT NOT NULL REFERENCES attempt(id),
    ordinal INTEGER NOT NULL CHECK (ordinal>0),
    worktree_binding_id TEXT NOT NULL REFERENCES attempt_worktree_binding(id),
    acquire_operation_id TEXT NOT NULL UNIQUE REFERENCES session_acquire_operation(operation_id),
    adapter_ref TEXT NOT NULL CHECK (length(adapter_ref)>0),
    provider_session_key TEXT NOT NULL CHECK (length(provider_session_key)>0),
    established_at TEXT NOT NULL CHECK (length(established_at)>0),
    UNIQUE (attempt_id, ordinal)
) STRICT;

CREATE INDEX session_binding_provider_key
ON session_binding(adapter_ref, provider_session_key);

CREATE INDEX session_binding_attempt_history
ON session_binding(attempt_id, ordinal DESC);

CREATE TABLE session_binding_release (
    session_binding_id TEXT PRIMARY KEY REFERENCES session_binding(id),
    release_operation_id TEXT NOT NULL UNIQUE REFERENCES session_release_operation(operation_id),
    released_at TEXT NOT NULL CHECK (length(released_at)>0),
    evidence_digest TEXT NOT NULL CHECK (length(evidence_digest)>0)
) STRICT;

CREATE TABLE executor_binding (
    id TEXT PRIMARY KEY CHECK (length(id)>0),
    attempt_id TEXT NOT NULL REFERENCES attempt(id),
    session_binding_id TEXT NOT NULL REFERENCES session_binding(id),
    launch_operation_id TEXT NOT NULL UNIQUE REFERENCES launch_operation(operation_id),
    adapter_ref TEXT NOT NULL CHECK (length(adapter_ref)>0),
    provider_executor_key TEXT NOT NULL CHECK (length(provider_executor_key)>0),
    established_at TEXT NOT NULL CHECK (length(established_at)>0)
) STRICT;

CREATE INDEX executor_binding_provider_key
ON executor_binding(adapter_ref, provider_executor_key);

CREATE INDEX executor_binding_attempt
ON executor_binding(attempt_id, established_at DESC);

CREATE TABLE executor_binding_termination (
    executor_binding_id TEXT PRIMARY KEY REFERENCES executor_binding(id),
    terminal_kind TEXT NOT NULL CHECK (terminal_kind IN ('completed','failed','interrupted','provider-gone')),
    interrupt_operation_id TEXT UNIQUE REFERENCES interrupt_operation(operation_id),
    observed_at TEXT NOT NULL CHECK (length(observed_at)>0),
    evidence_digest TEXT NOT NULL CHECK (length(evidence_digest)>0),
    CHECK ((terminal_kind='interrupted' AND interrupt_operation_id IS NOT NULL) OR
           (terminal_kind<>'interrupted'))
) STRICT;

CREATE TABLE worker_input_answer_origin (
    id TEXT PRIMARY KEY CHECK (length(id)>0),
    worker_input_id TEXT NOT NULL UNIQUE REFERENCES worker_input(id) DEFERRABLE INITIALLY DEFERRED,
    decision_id TEXT NOT NULL REFERENCES decision(id),
    answer_id TEXT NOT NULL UNIQUE REFERENCES decision_answer(id)
) STRICT;

CREATE TABLE worker_input (
    id TEXT PRIMARY KEY CHECK (length(id)>0),
    attempt_id TEXT NOT NULL REFERENCES attempt(id),
    executor_binding_id TEXT NOT NULL REFERENCES executor_binding(id),
    ordinal INTEGER NOT NULL CHECK (ordinal>0),
    payload BLOB NOT NULL,
    payload_digest TEXT NOT NULL CHECK (length(payload_digest)>0),
    origin_kind TEXT NOT NULL CHECK (origin_kind IN ('operator','supervisor','answer')),
    answer_origin_id TEXT UNIQUE REFERENCES worker_input_answer_origin(id),
    created_at TEXT NOT NULL CHECK (length(created_at)>0),
    UNIQUE (executor_binding_id, ordinal),
    CHECK ((origin_kind='answer' AND answer_origin_id IS NOT NULL) OR
           (origin_kind<>'answer' AND answer_origin_id IS NULL))
) STRICT;

CREATE INDEX worker_input_current_order
ON worker_input(executor_binding_id, ordinal);

CREATE TABLE worker_input_acknowledgement (
    worker_input_id TEXT PRIMARY KEY REFERENCES worker_input(id),
    executor_binding_id TEXT NOT NULL REFERENCES executor_binding(id),
    actor_kind TEXT NOT NULL CHECK (actor_kind='worker'),
    observed_at TEXT NOT NULL CHECK (length(observed_at)>0),
    evidence_digest TEXT NOT NULL CHECK (length(evidence_digest)>0)
) STRICT;

CREATE INDEX worker_input_ack_executor
ON worker_input_acknowledgement(executor_binding_id, observed_at);

CREATE TABLE worker_report (
    id TEXT PRIMARY KEY CHECK (length(id)>0),
    attempt_id TEXT NOT NULL REFERENCES attempt(id),
    executor_binding_id TEXT REFERENCES executor_binding(id),
    source_prefix_digest TEXT NOT NULL CHECK (length(source_prefix_digest)>0),
    source_end_offset INTEGER NOT NULL CHECK (source_end_offset>=0),
    report_state TEXT NOT NULL CHECK (report_state IN ('working','paused','blocked','needs-decision','done','failed')),
    note TEXT NOT NULL,
    created_at TEXT NOT NULL CHECK (length(created_at)>0),
    UNIQUE (attempt_id, source_prefix_digest)
) STRICT;

CREATE INDEX worker_report_attempt_latest
ON worker_report(attempt_id, created_at DESC, id);

CREATE TABLE worker_report_acknowledgement (
    worker_report_id TEXT PRIMARY KEY REFERENCES worker_report(id),
    actor_kind TEXT NOT NULL CHECK (actor_kind IN ('operator','supervisor')),
    acknowledged_at TEXT NOT NULL CHECK (length(acknowledged_at)>0),
    evidence_digest TEXT NOT NULL CHECK (length(evidence_digest)>0)
) STRICT;

CREATE TABLE decision (
    id TEXT PRIMARY KEY CHECK (length(id)>0),
    task_id TEXT NOT NULL REFERENCES task(id),
    plan_id TEXT REFERENCES plan(id),
    attempt_id TEXT REFERENCES attempt(id),
    scope_kind TEXT NOT NULL CHECK (scope_kind IN ('task','plan','attempt')),
    triggering_worker_report_id TEXT REFERENCES worker_report(id),
    question TEXT NOT NULL CHECK (length(question)>0),
    choices_digest TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL CHECK (length(created_at)>0),
    CHECK ((scope_kind='task' AND plan_id IS NULL AND attempt_id IS NULL) OR
           (scope_kind='plan' AND plan_id IS NOT NULL AND attempt_id IS NULL) OR
           (scope_kind='attempt' AND plan_id IS NOT NULL AND attempt_id IS NOT NULL))
) STRICT;

CREATE INDEX decision_task_history
ON decision(task_id, created_at DESC);

CREATE TABLE decision_answer (
    id TEXT PRIMARY KEY CHECK (length(id)>0),
    decision_id TEXT NOT NULL UNIQUE REFERENCES decision(id),
    answer TEXT NOT NULL,
    answer_digest TEXT NOT NULL CHECK (length(answer_digest)>0),
    actor_kind TEXT NOT NULL CHECK (actor_kind IN ('operator','authorized-machine')),
    actor_ref TEXT NOT NULL DEFAULT '',
    answered_at TEXT NOT NULL CHECK (length(answered_at)>0)
) STRICT;

CREATE TABLE decision_closure (
    decision_id TEXT PRIMARY KEY REFERENCES decision(id),
    reason TEXT NOT NULL CHECK (reason IN ('stale','cancelled')),
    closed_at TEXT NOT NULL CHECK (length(closed_at)>0),
    evidence_digest TEXT NOT NULL CHECK (length(evidence_digest)>0)
) STRICT;

CREATE TABLE task_hold (
    id TEXT PRIMARY KEY CHECK (length(id)>0),
    task_id TEXT NOT NULL REFERENCES task(id),
    ordinal INTEGER NOT NULL CHECK (ordinal>0),
    kind TEXT NOT NULL CHECK (kind IN ('operator','blocked')),
    reason TEXT NOT NULL,
    evidence_digest TEXT NOT NULL CHECK (length(evidence_digest)>0),
    created_at TEXT NOT NULL CHECK (length(created_at)>0),
    UNIQUE (task_id, ordinal)
) STRICT;

CREATE INDEX task_hold_task_history
ON task_hold(task_id, ordinal DESC);

CREATE TABLE task_hold_blocked_on_task (
    hold_id TEXT PRIMARY KEY REFERENCES task_hold(id),
    blocked_on_task_id TEXT NOT NULL REFERENCES task(id),
    CHECK (hold_id <> blocked_on_task_id)
) STRICT;

CREATE TABLE task_hold_decision (
    hold_id TEXT PRIMARY KEY REFERENCES task_hold(id),
    decision_id TEXT NOT NULL REFERENCES decision(id)
) STRICT;

CREATE TABLE task_hold_recheck (
    hold_id TEXT PRIMARY KEY REFERENCES task_hold(id),
    not_before TEXT NOT NULL CHECK (length(not_before)>0)
) STRICT;

CREATE TABLE task_hold_resolution (
    hold_id TEXT PRIMARY KEY REFERENCES task_hold(id),
    resolution TEXT NOT NULL CHECK (resolution IN ('released','cancelled','superseded')),
    resolved_at TEXT NOT NULL CHECK (length(resolved_at)>0),
    evidence_digest TEXT NOT NULL CHECK (length(evidence_digest)>0)
) STRICT;

CREATE TABLE attempt_backoff (
    id TEXT PRIMARY KEY CHECK (length(id)>0),
    attempt_id TEXT NOT NULL REFERENCES attempt(id),
    ordinal INTEGER NOT NULL CHECK (ordinal>0),
    reason TEXT NOT NULL CHECK (reason IN ('usage-limit','rate-limit','provider-transient')),
    not_before TEXT NOT NULL CHECK (length(not_before)>0),
    evidence_digest TEXT NOT NULL CHECK (length(evidence_digest)>0),
    created_at TEXT NOT NULL CHECK (length(created_at)>0),
    UNIQUE (attempt_id, ordinal)
) STRICT;

CREATE INDEX attempt_backoff_attempt_history
ON attempt_backoff(attempt_id, ordinal DESC);

CREATE TABLE attempt_backoff_resolution (
    backoff_id TEXT PRIMARY KEY REFERENCES attempt_backoff(id),
    resolution TEXT NOT NULL CHECK (resolution IN ('resumed','cancelled','superseded')),
    resolved_at TEXT NOT NULL CHECK (length(resolved_at)>0),
    evidence_digest TEXT NOT NULL CHECK (length(evidence_digest)>0)
) STRICT;

CREATE TABLE repair_target (
    repair_id TEXT PRIMARY KEY REFERENCES repair(id) DEFERRABLE INITIALLY DEFERRED,
    project_id TEXT REFERENCES project(id),
    workspace_binding_id TEXT REFERENCES workspace_binding(id),
    task_id TEXT REFERENCES task(id),
    plan_id TEXT REFERENCES plan(id),
    attempt_id TEXT REFERENCES attempt(id),
    external_operation_id TEXT REFERENCES external_operation(id),
    worktree_binding_id TEXT REFERENCES attempt_worktree_binding(id),
    session_binding_id TEXT REFERENCES session_binding(id),
    executor_binding_id TEXT REFERENCES executor_binding(id),
    CHECK (
      (project_id IS NOT NULL) +
      (workspace_binding_id IS NOT NULL) +
      (task_id IS NOT NULL) +
      (plan_id IS NOT NULL) +
      (attempt_id IS NOT NULL) +
      (external_operation_id IS NOT NULL) +
      (worktree_binding_id IS NOT NULL) +
      (session_binding_id IS NOT NULL) +
      (executor_binding_id IS NOT NULL) = 1
    )
) STRICT;

CREATE TABLE repair (
    id TEXT PRIMARY KEY CHECK (length(id)>0),
    repair_code TEXT NOT NULL CHECK (length(repair_code)>0 AND length(repair_code)<=128),
    reason TEXT NOT NULL,
    evidence_digest TEXT NOT NULL CHECK (length(evidence_digest)>0),
    created_at TEXT NOT NULL CHECK (length(created_at)>0),
    FOREIGN KEY (id) REFERENCES repair_target(repair_id) DEFERRABLE INITIALLY DEFERRED
) STRICT;

CREATE INDEX repair_code_created
ON repair(repair_code, created_at DESC);

CREATE INDEX repair_target_project
ON repair_target(project_id) WHERE project_id IS NOT NULL;
CREATE INDEX repair_target_workspace
ON repair_target(workspace_binding_id) WHERE workspace_binding_id IS NOT NULL;
CREATE INDEX repair_target_task
ON repair_target(task_id) WHERE task_id IS NOT NULL;
CREATE INDEX repair_target_plan
ON repair_target(plan_id) WHERE plan_id IS NOT NULL;
CREATE INDEX repair_target_attempt
ON repair_target(attempt_id) WHERE attempt_id IS NOT NULL;
CREATE INDEX repair_target_external_operation
ON repair_target(external_operation_id) WHERE external_operation_id IS NOT NULL;
CREATE INDEX repair_target_worktree
ON repair_target(worktree_binding_id) WHERE worktree_binding_id IS NOT NULL;
CREATE INDEX repair_target_session
ON repair_target(session_binding_id) WHERE session_binding_id IS NOT NULL;
CREATE INDEX repair_target_executor
ON repair_target(executor_binding_id) WHERE executor_binding_id IS NOT NULL;

CREATE TABLE repair_resolution (
    repair_id TEXT PRIMARY KEY REFERENCES repair(id),
    resolution TEXT NOT NULL CHECK (
      resolution IN ('repaired','no-longer-applicable','superseded','operator-attested')
    ),
    resolved_at TEXT NOT NULL CHECK (length(resolved_at)>0),
    evidence_digest TEXT NOT NULL CHECK (length(evidence_digest)>0),
    actor_ref TEXT NOT NULL DEFAULT ''
) STRICT;

CREATE TABLE terminal_receipt (
    id TEXT PRIMARY KEY CHECK (length(id)>0),
    attempt_id TEXT NOT NULL UNIQUE REFERENCES attempt(id),
    outcome_kind TEXT NOT NULL CHECK (outcome_kind IN ('candidate','no-candidate')),
    candidate_revision TEXT NOT NULL DEFAULT '',
    evidence_digest TEXT NOT NULL CHECK (length(evidence_digest)>0),
    created_at TEXT NOT NULL CHECK (length(created_at)>0),
    CHECK ((outcome_kind='candidate' AND candidate_revision<>'') OR
           (outcome_kind='no-candidate' AND candidate_revision=''))
) STRICT;

CREATE INDEX terminal_receipt_candidate
ON terminal_receipt(candidate_revision) WHERE candidate_revision<>'';

CREATE TABLE qualification_verdict (
    operation_id TEXT PRIMARY KEY REFERENCES qualification_operation(operation_id),
    terminal_receipt_id TEXT NOT NULL REFERENCES terminal_receipt(id),
    verdict TEXT NOT NULL CHECK (verdict IN ('qualified','disqualified')),
    evidence_digest TEXT NOT NULL CHECK (length(evidence_digest)>0),
    decided_at TEXT NOT NULL CHECK (length(decided_at)>0)
) STRICT;

CREATE TABLE integration_receipt (
    operation_id TEXT PRIMARY KEY REFERENCES integration_operation(operation_id),
    plan_id TEXT NOT NULL REFERENCES plan(id),
    terminal_receipt_id TEXT NOT NULL REFERENCES terminal_receipt(id),
    integrated_revision TEXT NOT NULL CHECK (length(integrated_revision)>0),
    target_ref TEXT NOT NULL CHECK (length(target_ref)>0),
    evidence_digest TEXT NOT NULL CHECK (length(evidence_digest)>0),
    created_at TEXT NOT NULL CHECK (length(created_at)>0)
) STRICT;

CREATE INDEX integration_receipt_plan
ON integration_receipt(plan_id, created_at DESC);

CREATE TABLE artifact (
    id TEXT PRIMARY KEY CHECK (length(id)>0),
    production_operation_id TEXT NOT NULL UNIQUE REFERENCES production_operation(operation_id),
    plan_id TEXT NOT NULL REFERENCES plan(id),
    integration_receipt_id TEXT NOT NULL REFERENCES integration_receipt(operation_id),
    artifact_kind TEXT NOT NULL CHECK (length(artifact_kind)>0),
    artifact_digest TEXT NOT NULL CHECK (length(artifact_digest)>0),
    locator TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL CHECK (length(created_at)>0)
) STRICT;

CREATE TABLE publication_receipt (
    operation_id TEXT PRIMARY KEY REFERENCES publication_operation(operation_id),
    artifact_id TEXT NOT NULL REFERENCES artifact(id),
    target_ref TEXT NOT NULL CHECK (length(target_ref)>0),
    published_identity TEXT NOT NULL CHECK (length(published_identity)>0),
    evidence_digest TEXT NOT NULL CHECK (length(evidence_digest)>0),
    created_at TEXT NOT NULL CHECK (length(created_at)>0)
) STRICT;

CREATE TABLE legacy_import (
    id TEXT PRIMARY KEY CHECK (length(id)>0),
    fleet_id TEXT NOT NULL REFERENCES fleet(fleet_id),
    source_user_version INTEGER NOT NULL CHECK (source_user_version=18),
    source_db_sha256 TEXT NOT NULL CHECK (length(source_db_sha256)>0),
    archive_db_sha256 TEXT NOT NULL CHECK (length(archive_db_sha256)>0),
    manifest_sha256 TEXT NOT NULL CHECK (length(manifest_sha256)>0),
    target_ddl_sha256 TEXT NOT NULL CHECK (length(target_ddl_sha256)>0),
    target_schema_fingerprint TEXT NOT NULL CHECK (length(target_schema_fingerprint)>0),
    imported_at TEXT NOT NULL CHECK (length(imported_at)>0),
    UNIQUE (fleet_id, source_db_sha256)
) STRICT;

CREATE TABLE legacy_import_project (
    import_id TEXT NOT NULL REFERENCES legacy_import(id),
    project_id TEXT NOT NULL REFERENCES project(id),
    workspace_binding_id TEXT NOT NULL REFERENCES workspace_binding(id),
    policy_revision_id TEXT NOT NULL REFERENCES policy_revision(id),
    evidence_digest TEXT NOT NULL CHECK (length(evidence_digest)>0),
    PRIMARY KEY (import_id, project_id)
) STRICT;

CREATE TRIGGER task_insert_guard
BEFORE INSERT ON task
BEGIN
  SELECT CASE WHEN (SELECT retired_at FROM project WHERE id=NEW.project_id)<>''
    THEN RAISE(ABORT,'task requires active project') END;
  SELECT CASE WHEN NEW.supersedes_task_id IS NOT NULL AND NEW.supersedes_task_id=NEW.id
    THEN RAISE(ABORT,'task cannot supersede itself') END;
  SELECT CASE WHEN NEW.supersedes_task_id IS NOT NULL AND
    (SELECT project_id FROM task WHERE id=NEW.supersedes_task_id)<>NEW.project_id
    THEN RAISE(ABORT,'task predecessor project mismatch') END;
END;

CREATE TRIGGER task_update_guard
BEFORE UPDATE ON task
BEGIN
  SELECT CASE WHEN
    NEW.id<>OLD.id OR NEW.project_id<>OLD.project_id OR NEW.ordinal<>OLD.ordinal OR
    NEW.goal<>OLD.goal OR NEW.goal_digest<>OLD.goal_digest OR
    NEW.supersedes_task_id IS NOT OLD.supersedes_task_id OR NEW.created_at<>OLD.created_at
  THEN RAISE(ABORT,'task immutable fields') END;
  SELECT CASE WHEN OLD.lifecycle<>'active' AND NEW.lifecycle<>OLD.lifecycle
    THEN RAISE(ABORT,'task terminal reopen') END;
  SELECT CASE WHEN OLD.terminal_at<>'' AND NEW.terminal_at<>OLD.terminal_at
    THEN RAISE(ABORT,'task terminal timestamp immutable') END;
  SELECT CASE WHEN OLD.lifecycle='active' AND NEW.lifecycle NOT IN ('active','satisfied','superseded','abandoned')
    THEN RAISE(ABORT,'task lifecycle') END;
END;

CREATE TRIGGER task_archive_insert_guard
BEFORE INSERT ON task_archive
BEGIN
  SELECT CASE WHEN NOT EXISTS (
    SELECT 1 FROM task t
    WHERE t.id=NEW.task_id AND t.lifecycle IN ('satisfied','superseded','abandoned')
  ) THEN RAISE(ABORT,'task archive requires exact terminal task') END;
  SELECT CASE WHEN EXISTS (
    SELECT 1 FROM plan p WHERE p.task_id=NEW.task_id AND p.lifecycle='active'
  ) THEN RAISE(ABORT,'task archive blocked by active plan') END;
  SELECT CASE WHEN EXISTS (
    SELECT 1 FROM attempt a
    JOIN plan p ON p.id=a.plan_id
    WHERE p.task_id=NEW.task_id AND a.lifecycle='active'
  ) THEN RAISE(ABORT,'task archive blocked by active attempt') END;
  SELECT CASE WHEN EXISTS (
    SELECT 1 FROM external_operation o
    WHERE o.task_id=NEW.task_id AND o.state IN ('prepared','submitted','uncertain')
  ) THEN RAISE(ABORT,'task archive blocked by unresolved operation') END;
  SELECT CASE WHEN EXISTS (
    SELECT 1 FROM task_hold h
    LEFT JOIN task_hold_blocked_on_task b ON b.hold_id=h.id
    WHERE (h.task_id=NEW.task_id OR b.blocked_on_task_id=NEW.task_id)
      AND NOT EXISTS (SELECT 1 FROM task_hold_resolution r WHERE r.hold_id=h.id)
  ) THEN RAISE(ABORT,'task archive blocked by open hold') END;
  SELECT CASE WHEN EXISTS (
    SELECT 1 FROM attempt_backoff b
    JOIN attempt a ON a.id=b.attempt_id
    JOIN plan p ON p.id=a.plan_id
    WHERE p.task_id=NEW.task_id
      AND NOT EXISTS (SELECT 1 FROM attempt_backoff_resolution r WHERE r.backoff_id=b.id)
  ) THEN RAISE(ABORT,'task archive blocked by open backoff') END;
  SELECT CASE WHEN EXISTS (
    SELECT 1 FROM attempt_worktree_binding w
    JOIN attempt a ON a.id=w.attempt_id
    JOIN plan p ON p.id=a.plan_id
    WHERE p.task_id=NEW.task_id
      AND NOT EXISTS (SELECT 1 FROM worktree_binding_release r WHERE r.binding_id=w.id)
  ) THEN RAISE(ABORT,'task archive blocked by open worktree') END;
  SELECT CASE WHEN EXISTS (
    SELECT 1 FROM session_binding s
    JOIN attempt a ON a.id=s.attempt_id
    JOIN plan p ON p.id=a.plan_id
    WHERE p.task_id=NEW.task_id
      AND NOT EXISTS (SELECT 1 FROM session_binding_release r WHERE r.session_binding_id=s.id)
  ) THEN RAISE(ABORT,'task archive blocked by open session') END;
  SELECT CASE WHEN EXISTS (
    SELECT 1 FROM executor_binding e
    JOIN attempt a ON a.id=e.attempt_id
    JOIN plan p ON p.id=a.plan_id
    WHERE p.task_id=NEW.task_id
      AND NOT EXISTS (SELECT 1 FROM executor_binding_termination t WHERE t.executor_binding_id=e.id)
  ) THEN RAISE(ABORT,'task archive blocked by open executor') END;
  SELECT CASE WHEN EXISTS (
    SELECT 1 FROM worker_report wr
    JOIN attempt a ON a.id=wr.attempt_id
    JOIN plan p ON p.id=a.plan_id
    WHERE p.task_id=NEW.task_id
      AND wr.report_state IN ('paused','blocked','needs-decision','done','failed')
      AND NOT EXISTS (
        SELECT 1 FROM worker_report_acknowledgement ack WHERE ack.worker_report_id=wr.id
      )
  ) THEN RAISE(ABORT,'task archive blocked by unacknowledged report') END;
  SELECT CASE WHEN EXISTS (
    SELECT 1 FROM decision d
    WHERE d.task_id=NEW.task_id
      AND NOT EXISTS (SELECT 1 FROM decision_answer a WHERE a.decision_id=d.id)
      AND NOT EXISTS (SELECT 1 FROM decision_closure c WHERE c.decision_id=d.id)
  ) THEN RAISE(ABORT,'task archive blocked by open decision') END;
  SELECT CASE WHEN EXISTS (
    SELECT 1
    FROM repair r
    JOIN repair_target rt ON rt.repair_id=r.id
    WHERE NOT EXISTS (SELECT 1 FROM repair_resolution rr WHERE rr.repair_id=r.id)
      AND (
        rt.project_id=(SELECT project_id FROM task WHERE id=NEW.task_id) OR
        rt.workspace_binding_id IN (SELECT workspace_binding_id FROM plan WHERE task_id=NEW.task_id) OR
        rt.task_id=NEW.task_id OR
        rt.plan_id IN (SELECT id FROM plan WHERE task_id=NEW.task_id) OR
        rt.attempt_id IN (
          SELECT a.id FROM attempt a JOIN plan p ON p.id=a.plan_id WHERE p.task_id=NEW.task_id
        ) OR
        rt.external_operation_id IN (
          SELECT id FROM external_operation WHERE task_id=NEW.task_id
        ) OR
        rt.worktree_binding_id IN (
          SELECT w.id FROM attempt_worktree_binding w
          JOIN attempt a ON a.id=w.attempt_id
          JOIN plan p ON p.id=a.plan_id
          WHERE p.task_id=NEW.task_id
        ) OR
        rt.session_binding_id IN (
          SELECT s.id FROM session_binding s
          JOIN attempt a ON a.id=s.attempt_id
          JOIN plan p ON p.id=a.plan_id
          WHERE p.task_id=NEW.task_id
        ) OR
        rt.executor_binding_id IN (
          SELECT e.id FROM executor_binding e
          JOIN attempt a ON a.id=e.attempt_id
          JOIN plan p ON p.id=a.plan_id
          WHERE p.task_id=NEW.task_id
        )
      )
  ) THEN RAISE(ABORT,'task archive blocked by open repair') END;
END;

CREATE TRIGGER plan_insert_guard
BEFORE INSERT ON plan
BEGIN
  SELECT CASE WHEN (SELECT lifecycle FROM task WHERE id=NEW.task_id)<>'active'
    THEN RAISE(ABORT,'plan requires active task') END;
  SELECT CASE WHEN (SELECT superseded_at FROM workspace_binding WHERE id=NEW.workspace_binding_id)<>''
    THEN RAISE(ABORT,'plan requires current workspace binding') END;
  SELECT CASE WHEN (SELECT superseded_at FROM policy_revision WHERE id=NEW.policy_revision_id)<>''
    THEN RAISE(ABORT,'plan requires current policy revision') END;
  SELECT CASE WHEN NEW.lineage_kind='root' AND
    (NEW.ordinal<>1 OR EXISTS (SELECT 1 FROM plan WHERE task_id=NEW.task_id))
    THEN RAISE(ABORT,'root plan must be first plan') END;
  SELECT CASE WHEN NEW.lineage_kind='replan' AND
    (SELECT lifecycle FROM plan WHERE id=NEW.predecessor_plan_id)<>'superseded'
    THEN RAISE(ABORT,'replan predecessor must be superseded') END;
  SELECT CASE WHEN NEW.lineage_kind='advance' AND
    (SELECT lifecycle FROM plan WHERE id=NEW.predecessor_plan_id)<>'satisfied'
    THEN RAISE(ABORT,'advance predecessor must be satisfied') END;
  SELECT CASE WHEN NEW.predecessor_plan_id IS NOT NULL AND
    NEW.ordinal<>(SELECT ordinal+1 FROM plan WHERE id=NEW.predecessor_plan_id)
    THEN RAISE(ABORT,'successor plan ordinal mismatch') END;
  SELECT CASE WHEN
    (SELECT project_id FROM task WHERE id=NEW.task_id) <>
    (SELECT project_id FROM workspace_binding WHERE id=NEW.workspace_binding_id)
  THEN RAISE(ABORT,'plan workspace project mismatch') END;
  SELECT CASE WHEN
    (SELECT project_id FROM task WHERE id=NEW.task_id) <>
    (SELECT project_id FROM policy_revision WHERE id=NEW.policy_revision_id)
  THEN RAISE(ABORT,'plan policy project mismatch') END;
  SELECT CASE WHEN NEW.predecessor_plan_id IS NOT NULL AND
    (SELECT task_id FROM plan WHERE id=NEW.predecessor_plan_id) <> NEW.task_id
  THEN RAISE(ABORT,'plan predecessor task mismatch') END;
END;

CREATE TRIGGER plan_update_guard
BEFORE UPDATE ON plan
BEGIN
  SELECT CASE WHEN
    NEW.id<>OLD.id OR NEW.task_id<>OLD.task_id OR NEW.ordinal<>OLD.ordinal OR
    NEW.lineage_kind<>OLD.lineage_kind OR NEW.predecessor_plan_id IS NOT OLD.predecessor_plan_id OR
    NEW.intent<>OLD.intent OR NEW.judgment<>OLD.judgment OR NEW.basis<>OLD.basis OR
    NEW.brief<>OLD.brief OR NEW.brief_digest<>OLD.brief_digest OR
    NEW.workspace_binding_id<>OLD.workspace_binding_id OR NEW.policy_revision_id<>OLD.policy_revision_id OR
    NEW.created_at<>OLD.created_at
  THEN RAISE(ABORT,'plan immutable fields') END;
  SELECT CASE WHEN OLD.lifecycle<>'active' AND NEW.lifecycle<>OLD.lifecycle
    THEN RAISE(ABORT,'plan terminal reopen') END;
  SELECT CASE WHEN OLD.terminal_at<>'' AND NEW.terminal_at<>OLD.terminal_at
    THEN RAISE(ABORT,'plan terminal timestamp immutable') END;
END;

CREATE TRIGGER attempt_insert_guard
BEFORE INSERT ON attempt
BEGIN
  SELECT CASE WHEN (SELECT lifecycle FROM plan WHERE id=NEW.plan_id)<>'active'
    THEN RAISE(ABORT,'attempt requires active plan') END;
END;

CREATE TRIGGER attempt_update_guard
BEFORE UPDATE ON attempt
BEGIN
  SELECT CASE WHEN
    NEW.id<>OLD.id OR NEW.plan_id<>OLD.plan_id OR NEW.ordinal<>OLD.ordinal OR
    NEW.worker_harness_ref<>OLD.worker_harness_ref OR NEW.worker_harness_version<>OLD.worker_harness_version OR
    NEW.worker_profile_ref<>OLD.worker_profile_ref OR NEW.model_ref<>OLD.model_ref OR
    NEW.effort_ref<>OLD.effort_ref OR NEW.session_adapter_ref<>OLD.session_adapter_ref OR
    NEW.created_at<>OLD.created_at
  THEN RAISE(ABORT,'attempt immutable fields') END;
  SELECT CASE WHEN OLD.lifecycle<>'active' AND NEW.lifecycle<>OLD.lifecycle
    THEN RAISE(ABORT,'attempt terminal reopen') END;
  SELECT CASE WHEN OLD.terminal_at<>'' AND NEW.terminal_at<>OLD.terminal_at
    THEN RAISE(ABORT,'attempt terminal timestamp immutable') END;
  SELECT CASE WHEN NEW.lifecycle<>'active' AND EXISTS (
    SELECT 1 FROM attempt_backoff b
    WHERE b.attempt_id=OLD.id
      AND NOT EXISTS (SELECT 1 FROM attempt_backoff_resolution r WHERE r.backoff_id=b.id)
  ) THEN RAISE(ABORT,'attempt has unresolved backoff') END;
END;

CREATE TRIGGER external_operation_insert_guard
BEFORE INSERT ON external_operation
BEGIN
  SELECT CASE WHEN NEW.state<>'prepared' THEN RAISE(ABORT,'operation must begin prepared') END;
  SELECT CASE WHEN NEW.task_id IS NOT NULL AND
    (SELECT project_id FROM task WHERE id=NEW.task_id)<>NEW.project_id
  THEN RAISE(ABORT,'operation task project mismatch') END;
  SELECT CASE WHEN NEW.plan_id IS NOT NULL AND
    (SELECT task_id FROM plan WHERE id=NEW.plan_id) IS NOT NEW.task_id
  THEN RAISE(ABORT,'operation plan task mismatch') END;
  SELECT CASE WHEN NEW.attempt_id IS NOT NULL AND
    (SELECT plan_id FROM attempt WHERE id=NEW.attempt_id) IS NOT NEW.plan_id
  THEN RAISE(ABORT,'operation attempt plan mismatch') END;
END;

CREATE TRIGGER external_operation_after_insert
AFTER INSERT ON external_operation
BEGIN
  INSERT INTO external_operation_event(operation_id,from_state,to_state,observed_at,evidence_digest)
  VALUES(NEW.id,'',NEW.state,NEW.state_changed_at,NEW.state_evidence_digest);
END;

CREATE TRIGGER external_operation_update_guard
BEFORE UPDATE ON external_operation
BEGIN
  SELECT CASE WHEN
    NEW.id<>OLD.id OR NEW.kind<>OLD.kind OR NEW.adapter_ref<>OLD.adapter_ref OR
    NEW.operation_key<>OLD.operation_key OR NEW.request_digest<>OLD.request_digest OR
    NEW.project_id<>OLD.project_id OR NEW.task_id IS NOT OLD.task_id OR
    NEW.plan_id IS NOT OLD.plan_id OR NEW.attempt_id IS NOT OLD.attempt_id OR
    NEW.primary_scope_kind<>OLD.primary_scope_kind OR NEW.primary_scope_key<>OLD.primary_scope_key OR
    NEW.created_at<>OLD.created_at
  THEN RAISE(ABORT,'operation immutable fields') END;

  SELECT CASE WHEN NOT (
    (OLD.state='prepared' AND NEW.state IN ('submitted','succeeded','no-effect')) OR
    (OLD.state='submitted' AND NEW.state IN ('succeeded','rejected','no-effect','uncertain')) OR
    (OLD.state='uncertain' AND NEW.state IN ('succeeded','rejected','no-effect'))
  ) THEN RAISE(ABORT,'illegal operation transition') END;

  SELECT CASE WHEN ((SELECT count(*) FROM worktree_create_operation WHERE operation_id=NEW.id) + (SELECT count(*) FROM worktree_remove_operation WHERE operation_id=NEW.id) + (SELECT count(*) FROM session_acquire_operation WHERE operation_id=NEW.id) + (SELECT count(*) FROM session_release_operation WHERE operation_id=NEW.id) + (SELECT count(*) FROM launch_operation WHERE operation_id=NEW.id) + (SELECT count(*) FROM worker_wake_operation WHERE operation_id=NEW.id) + (SELECT count(*) FROM interrupt_operation WHERE operation_id=NEW.id) + (SELECT count(*) FROM executor_residual_cleanup_operation WHERE operation_id=NEW.id) + (SELECT count(*) FROM qualification_operation WHERE operation_id=NEW.id) + (SELECT count(*) FROM integration_operation WHERE operation_id=NEW.id) + (SELECT count(*) FROM production_operation WHERE operation_id=NEW.id) + (SELECT count(*) FROM publication_operation WHERE operation_id=NEW.id)) <> 1
    THEN RAISE(ABORT,'operation requires exactly one typed child') END;

  SELECT CASE WHEN NOT EXISTS (
    SELECT 1 FROM operation_scope_claim c
    WHERE c.operation_id=NEW.id
      AND c.scope_kind=NEW.primary_scope_kind
      AND c.scope_key=NEW.primary_scope_key
  ) THEN RAISE(ABORT,'operation missing primary scope claim') END;

  SELECT CASE WHEN OLD.submitted_at<>'' AND NEW.submitted_at<>OLD.submitted_at
    THEN RAISE(ABORT,'submitted timestamp immutable') END;
  SELECT CASE WHEN OLD.finalized_at<>'' AND NEW.finalized_at<>OLD.finalized_at
    THEN RAISE(ABORT,'finalized timestamp immutable') END;
  SELECT CASE WHEN NEW.state_changed_at=OLD.state_changed_at
    THEN RAISE(ABORT,'state change timestamp must advance') END;
  SELECT CASE WHEN NEW.state_evidence_digest=''
    THEN RAISE(ABORT,'state transition evidence required') END;

  SELECT CASE WHEN NEW.state='submitted' AND NEW.submitted_at=''
    THEN RAISE(ABORT,'submitted timestamp required') END;
  SELECT CASE WHEN NEW.state IN ('succeeded','rejected','no-effect') AND NEW.finalized_at=''
    THEN RAISE(ABORT,'terminal timestamp required') END;
END;

CREATE TRIGGER external_operation_after_update
AFTER UPDATE OF state ON external_operation
BEGIN
  INSERT INTO external_operation_event(operation_id,from_state,to_state,observed_at,evidence_digest)
  VALUES(NEW.id,OLD.state,NEW.state,NEW.state_changed_at,NEW.state_evidence_digest);
END;

CREATE TRIGGER operation_scope_claim_guard
BEFORE INSERT ON operation_scope_claim
BEGIN
  SELECT CASE WHEN (SELECT state FROM external_operation WHERE id=NEW.operation_id)<>'prepared'
    THEN RAISE(ABORT,'scope claims acquired only while prepared') END;
  SELECT CASE WHEN EXISTS (
    SELECT 1 FROM operation_scope_claim c
    JOIN external_operation o ON o.id=c.operation_id
    WHERE c.scope_kind=NEW.scope_kind AND c.scope_key=NEW.scope_key
      AND c.operation_id<>NEW.operation_id
      AND o.state IN ('prepared','submitted','uncertain')
  ) THEN RAISE(ABORT,'scope already claimed') END;
END;

CREATE TRIGGER worktree_create_operation_insert_guard
BEFORE INSERT ON worktree_create_operation
BEGIN
  SELECT CASE WHEN NOT EXISTS(
    SELECT 1 FROM external_operation
    WHERE id=NEW.operation_id AND kind='worktree-create' AND state='prepared'
  ) THEN RAISE(ABORT,'typed operation kind/state mismatch') END;
  SELECT CASE WHEN EXISTS(SELECT 1 FROM worktree_remove_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM session_acquire_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM session_release_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM launch_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM worker_wake_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM interrupt_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM executor_residual_cleanup_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM qualification_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM integration_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM production_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM publication_operation WHERE operation_id=NEW.operation_id)
    THEN RAISE(ABORT,'operation already has different typed child') END;
END;

CREATE TRIGGER worktree_remove_operation_insert_guard
BEFORE INSERT ON worktree_remove_operation
BEGIN
  SELECT CASE WHEN NOT EXISTS(
    SELECT 1 FROM external_operation
    WHERE id=NEW.operation_id AND kind='worktree-remove' AND state='prepared'
  ) THEN RAISE(ABORT,'typed operation kind/state mismatch') END;
  SELECT CASE WHEN EXISTS(SELECT 1 FROM worktree_create_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM session_acquire_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM session_release_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM launch_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM worker_wake_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM interrupt_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM executor_residual_cleanup_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM qualification_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM integration_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM production_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM publication_operation WHERE operation_id=NEW.operation_id)
    THEN RAISE(ABORT,'operation already has different typed child') END;
END;

CREATE TRIGGER session_acquire_operation_insert_guard
BEFORE INSERT ON session_acquire_operation
BEGIN
  SELECT CASE WHEN NOT EXISTS(
    SELECT 1 FROM external_operation
    WHERE id=NEW.operation_id AND kind='session-acquire' AND state='prepared'
  ) THEN RAISE(ABORT,'typed operation kind/state mismatch') END;
  SELECT CASE WHEN EXISTS(SELECT 1 FROM worktree_create_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM worktree_remove_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM session_release_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM launch_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM worker_wake_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM interrupt_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM executor_residual_cleanup_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM qualification_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM integration_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM production_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM publication_operation WHERE operation_id=NEW.operation_id)
    THEN RAISE(ABORT,'operation already has different typed child') END;
END;

CREATE TRIGGER session_release_operation_insert_guard
BEFORE INSERT ON session_release_operation
BEGIN
  SELECT CASE WHEN NOT EXISTS(
    SELECT 1 FROM external_operation
    WHERE id=NEW.operation_id AND kind='session-release' AND state='prepared'
  ) THEN RAISE(ABORT,'typed operation kind/state mismatch') END;
  SELECT CASE WHEN EXISTS(SELECT 1 FROM worktree_create_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM worktree_remove_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM session_acquire_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM launch_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM worker_wake_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM interrupt_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM executor_residual_cleanup_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM qualification_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM integration_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM production_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM publication_operation WHERE operation_id=NEW.operation_id)
    THEN RAISE(ABORT,'operation already has different typed child') END;
END;

CREATE TRIGGER launch_operation_insert_guard
BEFORE INSERT ON launch_operation
BEGIN
  SELECT CASE WHEN NOT EXISTS(
    SELECT 1 FROM external_operation
    WHERE id=NEW.operation_id AND kind='launch' AND state='prepared'
  ) THEN RAISE(ABORT,'typed operation kind/state mismatch') END;
  SELECT CASE WHEN EXISTS(SELECT 1 FROM worktree_create_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM worktree_remove_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM session_acquire_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM session_release_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM worker_wake_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM interrupt_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM executor_residual_cleanup_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM qualification_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM integration_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM production_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM publication_operation WHERE operation_id=NEW.operation_id)
    THEN RAISE(ABORT,'operation already has different typed child') END;
END;

CREATE TRIGGER worker_wake_operation_insert_guard
BEFORE INSERT ON worker_wake_operation
BEGIN
  SELECT CASE WHEN NOT EXISTS(
    SELECT 1 FROM external_operation
    WHERE id=NEW.operation_id AND kind='worker-wake' AND state='prepared'
  ) THEN RAISE(ABORT,'typed operation kind/state mismatch') END;
  SELECT CASE WHEN EXISTS(SELECT 1 FROM worktree_create_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM worktree_remove_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM session_acquire_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM session_release_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM launch_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM interrupt_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM executor_residual_cleanup_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM qualification_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM integration_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM production_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM publication_operation WHERE operation_id=NEW.operation_id)
    THEN RAISE(ABORT,'operation already has different typed child') END;
END;

CREATE TRIGGER interrupt_operation_insert_guard
BEFORE INSERT ON interrupt_operation
BEGIN
  SELECT CASE WHEN NOT EXISTS(
    SELECT 1 FROM external_operation
    WHERE id=NEW.operation_id AND kind='interrupt' AND state='prepared'
  ) THEN RAISE(ABORT,'typed operation kind/state mismatch') END;
  SELECT CASE WHEN EXISTS(SELECT 1 FROM worktree_create_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM worktree_remove_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM session_acquire_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM session_release_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM launch_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM worker_wake_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM executor_residual_cleanup_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM qualification_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM integration_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM production_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM publication_operation WHERE operation_id=NEW.operation_id)
    THEN RAISE(ABORT,'operation already has different typed child') END;
END;

CREATE TRIGGER executor_residual_cleanup_operation_insert_guard
BEFORE INSERT ON executor_residual_cleanup_operation
BEGIN
  SELECT CASE WHEN NOT EXISTS(
    SELECT 1 FROM external_operation
    WHERE id=NEW.operation_id AND kind='executor-residual-cleanup' AND state='prepared'
  ) THEN RAISE(ABORT,'typed operation kind/state mismatch') END;
  SELECT CASE WHEN EXISTS(SELECT 1 FROM worktree_create_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM worktree_remove_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM session_acquire_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM session_release_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM launch_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM worker_wake_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM interrupt_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM qualification_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM integration_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM production_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM publication_operation WHERE operation_id=NEW.operation_id)
    THEN RAISE(ABORT,'operation already has different typed child') END;
END;

CREATE TRIGGER qualification_operation_insert_guard
BEFORE INSERT ON qualification_operation
BEGIN
  SELECT CASE WHEN NOT EXISTS(
    SELECT 1 FROM external_operation
    WHERE id=NEW.operation_id AND kind='qualification' AND state='prepared'
  ) THEN RAISE(ABORT,'typed operation kind/state mismatch') END;
  SELECT CASE WHEN EXISTS(SELECT 1 FROM worktree_create_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM worktree_remove_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM session_acquire_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM session_release_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM launch_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM worker_wake_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM interrupt_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM executor_residual_cleanup_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM integration_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM production_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM publication_operation WHERE operation_id=NEW.operation_id)
    THEN RAISE(ABORT,'operation already has different typed child') END;
END;

CREATE TRIGGER integration_operation_insert_guard
BEFORE INSERT ON integration_operation
BEGIN
  SELECT CASE WHEN NOT EXISTS(
    SELECT 1 FROM external_operation
    WHERE id=NEW.operation_id AND kind='integration' AND state='prepared'
  ) THEN RAISE(ABORT,'typed operation kind/state mismatch') END;
  SELECT CASE WHEN EXISTS(SELECT 1 FROM worktree_create_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM worktree_remove_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM session_acquire_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM session_release_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM launch_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM worker_wake_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM interrupt_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM executor_residual_cleanup_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM qualification_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM production_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM publication_operation WHERE operation_id=NEW.operation_id)
    THEN RAISE(ABORT,'operation already has different typed child') END;
END;

CREATE TRIGGER production_operation_insert_guard
BEFORE INSERT ON production_operation
BEGIN
  SELECT CASE WHEN NOT EXISTS(
    SELECT 1 FROM external_operation
    WHERE id=NEW.operation_id AND kind='production' AND state='prepared'
  ) THEN RAISE(ABORT,'typed operation kind/state mismatch') END;
  SELECT CASE WHEN EXISTS(SELECT 1 FROM worktree_create_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM worktree_remove_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM session_acquire_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM session_release_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM launch_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM worker_wake_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM interrupt_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM executor_residual_cleanup_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM qualification_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM integration_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM publication_operation WHERE operation_id=NEW.operation_id)
    THEN RAISE(ABORT,'operation already has different typed child') END;
END;

CREATE TRIGGER publication_operation_insert_guard
BEFORE INSERT ON publication_operation
BEGIN
  SELECT CASE WHEN NOT EXISTS(
    SELECT 1 FROM external_operation
    WHERE id=NEW.operation_id AND kind='publication' AND state='prepared'
  ) THEN RAISE(ABORT,'typed operation kind/state mismatch') END;
  SELECT CASE WHEN EXISTS(SELECT 1 FROM worktree_create_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM worktree_remove_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM session_acquire_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM session_release_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM launch_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM worker_wake_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM interrupt_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM executor_residual_cleanup_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM qualification_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM integration_operation WHERE operation_id=NEW.operation_id) OR EXISTS(SELECT 1 FROM production_operation WHERE operation_id=NEW.operation_id)
    THEN RAISE(ABORT,'operation already has different typed child') END;
END;

CREATE TRIGGER worktree_create_operation_consistency
BEFORE INSERT ON worktree_create_operation
BEGIN
  SELECT CASE WHEN (SELECT lifecycle FROM attempt WHERE id=NEW.attempt_id)<>'active'
    THEN RAISE(ABORT,'worktree create requires active attempt') END;
  SELECT CASE WHEN (SELECT attempt_id FROM external_operation WHERE id=NEW.operation_id) IS NOT NEW.attempt_id
    THEN RAISE(ABORT,'worktree create owner mismatch') END;
  SELECT CASE WHEN (SELECT adapter_ref FROM external_operation WHERE id=NEW.operation_id)<>'builtin/git-worktree'
    THEN RAISE(ABORT,'worktree create adapter') END;
  SELECT CASE WHEN EXISTS (SELECT 1 FROM attempt_worktree_binding WHERE attempt_id=NEW.attempt_id)
    THEN RAISE(ABORT,'attempt already has worktree binding') END;
  SELECT CASE WHEN EXISTS (
    SELECT 1 FROM worktree_create_operation wc
    JOIN external_operation o ON o.id=wc.operation_id
    WHERE wc.attempt_id=NEW.attempt_id AND o.state IN ('prepared','submitted','uncertain')
  ) THEN RAISE(ABORT,'attempt has unresolved worktree create') END;
END;

CREATE TRIGGER attempt_worktree_binding_insert_guard
BEFORE INSERT ON attempt_worktree_binding
BEGIN
  SELECT CASE WHEN EXISTS (
    SELECT 1 FROM workspace_binding w
    WHERE w.superseded_at='' AND w.physical_identity_digest=NEW.physical_identity_digest
  ) THEN RAISE(ABORT,'worktree aliases current workspace physical identity') END;
  SELECT CASE WHEN EXISTS (
    SELECT 1 FROM attempt_worktree_binding b
    WHERE (b.physical_identity_digest=NEW.physical_identity_digest OR b.path=NEW.path)
      AND NOT EXISTS (SELECT 1 FROM worktree_binding_release r WHERE r.binding_id=b.id)
  ) THEN RAISE(ABORT,'worktree aliases open worktree') END;
  SELECT CASE WHEN NOT EXISTS (
    SELECT 1 FROM worktree_create_operation wc
    JOIN external_operation o ON o.id=wc.operation_id
    WHERE wc.operation_id=NEW.create_operation_id
      AND wc.attempt_id=NEW.attempt_id
      AND wc.binding_id=NEW.id
      AND wc.basis_revision=NEW.basis_revision
      AND o.state='succeeded'
      AND o.adapter_ref='builtin/git-worktree'
  ) THEN RAISE(ABORT,'worktree binding lacks exact successful create') END;
END;

CREATE TRIGGER worktree_remove_operation_consistency
BEFORE INSERT ON worktree_remove_operation
BEGIN
  SELECT CASE WHEN EXISTS (SELECT 1 FROM worktree_binding_release WHERE binding_id=NEW.binding_id)
    THEN RAISE(ABORT,'worktree binding already released') END;
  SELECT CASE WHEN EXISTS (
    SELECT 1 FROM session_binding s
    WHERE s.worktree_binding_id=NEW.binding_id
      AND NOT EXISTS (SELECT 1 FROM session_binding_release r WHERE r.session_binding_id=s.id)
  ) THEN RAISE(ABORT,'open session blocks worktree remove') END;
END;

CREATE TRIGGER worktree_binding_release_guard
BEFORE INSERT ON worktree_binding_release
BEGIN
  SELECT CASE WHEN NOT EXISTS (
    SELECT 1 FROM worktree_remove_operation wr
    JOIN external_operation o ON o.id=wr.operation_id
    WHERE wr.operation_id=NEW.remove_operation_id
      AND wr.binding_id=NEW.binding_id
      AND o.state='succeeded'
  ) THEN RAISE(ABORT,'worktree release lacks exact successful remove') END;
END;

CREATE TRIGGER session_acquire_operation_consistency
BEFORE INSERT ON session_acquire_operation
BEGIN
  SELECT CASE WHEN (SELECT lifecycle FROM attempt WHERE id=NEW.attempt_id)<>'active'
    THEN RAISE(ABORT,'session acquire requires active attempt') END;
  SELECT CASE WHEN EXISTS (SELECT 1 FROM session_binding WHERE attempt_id=NEW.attempt_id)
    THEN RAISE(ABORT,'attempt already has session binding') END;
  SELECT CASE WHEN EXISTS (
    SELECT 1 FROM session_acquire_operation sa
    JOIN external_operation o ON o.id=sa.operation_id
    WHERE sa.attempt_id=NEW.attempt_id AND o.state IN ('prepared','submitted','uncertain')
  ) THEN RAISE(ABORT,'attempt has unresolved session acquire') END;
  SELECT CASE WHEN (SELECT attempt_id FROM external_operation WHERE id=NEW.operation_id) IS NOT NEW.attempt_id
    THEN RAISE(ABORT,'session acquire owner mismatch') END;
  SELECT CASE WHEN (SELECT attempt_id FROM attempt_worktree_binding WHERE id=NEW.worktree_binding_id) IS NOT NEW.attempt_id
    THEN RAISE(ABORT,'session acquire worktree owner mismatch') END;
  SELECT CASE WHEN EXISTS (SELECT 1 FROM worktree_binding_release WHERE binding_id=NEW.worktree_binding_id)
    THEN RAISE(ABORT,'released worktree cannot acquire session') END;
END;

CREATE TRIGGER session_binding_insert_guard
BEFORE INSERT ON session_binding
BEGIN
  SELECT CASE WHEN NOT EXISTS (
    SELECT 1 FROM session_acquire_operation sa
    JOIN external_operation o ON o.id=sa.operation_id
    WHERE sa.operation_id=NEW.acquire_operation_id
      AND sa.attempt_id=NEW.attempt_id
      AND sa.worktree_binding_id=NEW.worktree_binding_id
      AND sa.binding_id=NEW.id
      AND o.state='succeeded'
      AND o.adapter_ref=NEW.adapter_ref
  ) THEN RAISE(ABORT,'session binding lacks exact successful acquire') END;
  SELECT CASE WHEN EXISTS (SELECT 1 FROM worktree_binding_release WHERE binding_id=NEW.worktree_binding_id)
    THEN RAISE(ABORT,'released worktree cannot bind session') END;
  SELECT CASE WHEN EXISTS (
    SELECT 1 FROM session_binding s
    WHERE s.attempt_id=NEW.attempt_id
  ) THEN RAISE(ABORT,'attempt already has session binding') END;
  SELECT CASE WHEN EXISTS (
    SELECT 1 FROM session_binding s
    WHERE s.adapter_ref=NEW.adapter_ref AND s.provider_session_key=NEW.provider_session_key
      AND NOT EXISTS (SELECT 1 FROM session_binding_release r WHERE r.session_binding_id=s.id)
  ) THEN RAISE(ABORT,'provider session key already owned by open binding') END;
END;

CREATE TRIGGER session_release_operation_consistency
BEFORE INSERT ON session_release_operation
BEGIN
  SELECT CASE WHEN EXISTS (SELECT 1 FROM session_binding_release WHERE session_binding_id=NEW.session_binding_id)
    THEN RAISE(ABORT,'session already released') END;
  SELECT CASE WHEN EXISTS (
    SELECT 1 FROM executor_binding e
    WHERE e.session_binding_id=NEW.session_binding_id
      AND NOT EXISTS (SELECT 1 FROM executor_binding_termination t WHERE t.executor_binding_id=e.id)
  ) THEN RAISE(ABORT,'open executor blocks session release') END;
END;

CREATE TRIGGER session_binding_release_guard
BEFORE INSERT ON session_binding_release
BEGIN
  SELECT CASE WHEN NOT EXISTS (
    SELECT 1 FROM session_release_operation sr
    JOIN external_operation o ON o.id=sr.operation_id
    WHERE sr.operation_id=NEW.release_operation_id
      AND sr.session_binding_id=NEW.session_binding_id
      AND o.state='succeeded'
  ) THEN RAISE(ABORT,'session release lacks exact successful operation') END;
END;

CREATE TRIGGER launch_operation_consistency
BEFORE INSERT ON launch_operation
BEGIN
  SELECT CASE WHEN EXISTS (SELECT 1 FROM executor_binding WHERE attempt_id=NEW.attempt_id)
    THEN RAISE(ABORT,'attempt already has executor binding') END;
  SELECT CASE WHEN EXISTS (
    SELECT 1 FROM launch_operation l
    JOIN external_operation o ON o.id=l.operation_id
    WHERE l.attempt_id=NEW.attempt_id AND o.state IN ('prepared','submitted','uncertain')
  ) THEN RAISE(ABORT,'attempt has unresolved launch') END;
  SELECT CASE WHEN (SELECT attempt_id FROM external_operation WHERE id=NEW.operation_id) IS NOT NEW.attempt_id
    THEN RAISE(ABORT,'launch owner mismatch') END;
  SELECT CASE WHEN (SELECT attempt_id FROM session_binding WHERE id=NEW.session_binding_id) IS NOT NEW.attempt_id
    THEN RAISE(ABORT,'launch session owner mismatch') END;
  SELECT CASE WHEN EXISTS (SELECT 1 FROM session_binding_release WHERE session_binding_id=NEW.session_binding_id)
    THEN RAISE(ABORT,'released session cannot launch') END;
  SELECT CASE WHEN (SELECT lifecycle FROM attempt WHERE id=NEW.attempt_id)<>'active'
    THEN RAISE(ABORT,'inactive attempt cannot launch') END;
END;

CREATE TRIGGER executor_binding_insert_guard
BEFORE INSERT ON executor_binding
BEGIN
  SELECT CASE WHEN NOT EXISTS (
    SELECT 1 FROM launch_operation l
    JOIN external_operation o ON o.id=l.operation_id
    WHERE l.operation_id=NEW.launch_operation_id
      AND l.attempt_id=NEW.attempt_id
      AND l.session_binding_id=NEW.session_binding_id
      AND l.binding_id=NEW.id
      AND o.state='succeeded'
      AND o.adapter_ref=NEW.adapter_ref
  ) THEN RAISE(ABORT,'executor binding lacks exact successful launch') END;
  SELECT CASE WHEN EXISTS (
    SELECT 1 FROM executor_binding e
    WHERE e.attempt_id=NEW.attempt_id
  ) THEN RAISE(ABORT,'attempt already has executor binding') END;
  SELECT CASE WHEN EXISTS (
    SELECT 1 FROM executor_binding e
    WHERE e.adapter_ref=NEW.adapter_ref AND e.provider_executor_key=NEW.provider_executor_key
      AND NOT EXISTS (SELECT 1 FROM executor_binding_termination t WHERE t.executor_binding_id=e.id)
  ) THEN RAISE(ABORT,'provider executor key already owned by open binding') END;
END;

CREATE TRIGGER worker_input_insert_guard
BEFORE INSERT ON worker_input
BEGIN
  SELECT CASE WHEN NEW.origin_kind='answer' AND NOT EXISTS (
    SELECT 1
    FROM worker_input_answer_origin ao
    JOIN decision_answer da ON da.id=ao.answer_id
    JOIN decision d ON d.id=ao.decision_id
    JOIN attempt a ON a.id=NEW.attempt_id
    JOIN plan p ON p.id=a.plan_id
    WHERE ao.id=NEW.answer_origin_id
      AND ao.worker_input_id=NEW.id
      AND da.decision_id=d.id
      AND (
        (d.scope_kind='attempt' AND d.attempt_id=NEW.attempt_id) OR
        (d.scope_kind='plan' AND d.plan_id=a.plan_id) OR
        (d.scope_kind='task' AND d.task_id=p.task_id)
      )
  ) THEN RAISE(ABORT,'answer-origin WorkerInput scope mismatch') END;
  SELECT CASE WHEN NEW.origin_kind<>'answer' AND EXISTS (
    SELECT 1 FROM worker_input_answer_origin ao WHERE ao.worker_input_id=NEW.id
  ) THEN RAISE(ABORT,'non-answer WorkerInput has answer origin') END;
  SELECT CASE WHEN NOT EXISTS (
    SELECT 1 FROM executor_binding e
    JOIN session_binding s ON s.id=e.session_binding_id
    JOIN attempt a ON a.id=e.attempt_id
    JOIN plan p ON p.id=a.plan_id
    WHERE e.id=NEW.executor_binding_id
      AND e.attempt_id=NEW.attempt_id
      AND a.lifecycle='active'
      AND p.lifecycle='active'
      AND NOT EXISTS (SELECT 1 FROM executor_binding_termination t WHERE t.executor_binding_id=e.id)
      AND NOT EXISTS (SELECT 1 FROM session_binding_release sr WHERE sr.session_binding_id=s.id)
  ) THEN RAISE(ABORT,'worker input stale executor/attempt') END;
END;

CREATE TRIGGER worker_input_answer_origin_guard
BEFORE INSERT ON worker_input_answer_origin
BEGIN
  SELECT CASE WHEN (SELECT decision_id FROM decision_answer WHERE id=NEW.answer_id)<>NEW.decision_id
    THEN RAISE(ABORT,'answer origin decision mismatch') END;
END;

CREATE TRIGGER worker_input_ack_guard
BEFORE INSERT ON worker_input_acknowledgement
BEGIN
  SELECT CASE WHEN (SELECT executor_binding_id FROM worker_input WHERE id=NEW.worker_input_id)<>NEW.executor_binding_id
    THEN RAISE(ABORT,'worker input acknowledgement executor mismatch') END;
END;

CREATE TRIGGER worker_report_insert_guard
BEFORE INSERT ON worker_report
BEGIN
  SELECT CASE WHEN NEW.executor_binding_id IS NOT NULL AND
    (SELECT attempt_id FROM executor_binding WHERE id=NEW.executor_binding_id)<>NEW.attempt_id
  THEN RAISE(ABORT,'worker report executor attempt mismatch') END;
END;

CREATE TRIGGER decision_insert_guard
BEFORE INSERT ON decision
BEGIN
  SELECT CASE WHEN NEW.plan_id IS NOT NULL AND
    (SELECT task_id FROM plan WHERE id=NEW.plan_id)<>NEW.task_id
  THEN RAISE(ABORT,'decision plan task mismatch') END;
  SELECT CASE WHEN NEW.attempt_id IS NOT NULL AND
    (SELECT plan_id FROM attempt WHERE id=NEW.attempt_id)<>NEW.plan_id
  THEN RAISE(ABORT,'decision attempt plan mismatch') END;
  SELECT CASE WHEN NEW.triggering_worker_report_id IS NOT NULL AND NEW.attempt_id IS NOT NULL AND
    (SELECT attempt_id FROM worker_report WHERE id=NEW.triggering_worker_report_id)<>NEW.attempt_id
  THEN RAISE(ABORT,'decision triggering report mismatch') END;
END;

CREATE TRIGGER decision_answer_guard
BEFORE INSERT ON decision_answer
BEGIN
  SELECT CASE WHEN EXISTS (SELECT 1 FROM decision_closure WHERE decision_id=NEW.decision_id)
    THEN RAISE(ABORT,'closed decision cannot be answered') END;
END;

CREATE TRIGGER decision_closure_guard
BEFORE INSERT ON decision_closure
BEGIN
  SELECT CASE WHEN EXISTS (SELECT 1 FROM decision_answer WHERE decision_id=NEW.decision_id)
    THEN RAISE(ABORT,'answered decision cannot close stale/cancelled') END;
END;

CREATE TRIGGER task_hold_blocked_guard
BEFORE INSERT ON task_hold_blocked_on_task
BEGIN
  SELECT CASE WHEN (SELECT kind FROM task_hold WHERE id=NEW.hold_id)<>'blocked'
    THEN RAISE(ABORT,'blocked-on task requires blocked hold') END;
  SELECT CASE WHEN (SELECT task_id FROM task_hold WHERE id=NEW.hold_id)=NEW.blocked_on_task_id
    THEN RAISE(ABORT,'task hold cannot block on itself') END;
END;

CREATE TRIGGER task_hold_decision_guard
BEFORE INSERT ON task_hold_decision
BEGIN
  SELECT CASE WHEN (SELECT task_id FROM task_hold WHERE id=NEW.hold_id)<>(SELECT task_id FROM decision WHERE id=NEW.decision_id)
    THEN RAISE(ABORT,'task hold decision task mismatch') END;
END;

CREATE TRIGGER attempt_backoff_insert_guard
BEFORE INSERT ON attempt_backoff
BEGIN
  SELECT CASE WHEN (SELECT lifecycle FROM attempt WHERE id=NEW.attempt_id)<>'active'
    THEN RAISE(ABORT,'backoff requires active attempt') END;
  SELECT CASE WHEN EXISTS (
    SELECT 1 FROM attempt_backoff b
    WHERE b.attempt_id=NEW.attempt_id
      AND NOT EXISTS (SELECT 1 FROM attempt_backoff_resolution r WHERE r.backoff_id=b.id)
  ) THEN RAISE(ABORT,'attempt already has unresolved backoff') END;
END;

CREATE TRIGGER repair_insert_guard
BEFORE INSERT ON repair
BEGIN
  SELECT CASE WHEN NOT EXISTS (SELECT 1 FROM repair_target WHERE repair_id=NEW.id)
    THEN RAISE(ABORT,'repair requires exactly one typed target') END;
END;

CREATE TRIGGER terminal_receipt_guard
BEFORE INSERT ON terminal_receipt
BEGIN
  SELECT CASE WHEN (SELECT lifecycle FROM attempt WHERE id=NEW.attempt_id)='active'
    THEN RAISE(ABORT,'terminal receipt requires terminal attempt') END;
END;

CREATE TRIGGER qualification_operation_consistency
BEFORE INSERT ON qualification_operation
BEGIN
  SELECT CASE WHEN (SELECT plan_id FROM attempt WHERE id=(SELECT attempt_id FROM terminal_receipt WHERE id=NEW.terminal_receipt_id))<>NEW.plan_id
    THEN RAISE(ABORT,'qualification receipt plan mismatch') END;
  SELECT CASE WHEN (SELECT policy_revision_id FROM plan WHERE id=NEW.plan_id)<>NEW.policy_revision_id
    THEN RAISE(ABORT,'qualification policy mismatch') END;
END;

CREATE TRIGGER qualification_verdict_guard
BEFORE INSERT ON qualification_verdict
BEGIN
  SELECT CASE WHEN NEW.terminal_receipt_id<>(SELECT terminal_receipt_id FROM qualification_operation WHERE operation_id=NEW.operation_id)
    THEN RAISE(ABORT,'qualification verdict receipt mismatch') END;
  SELECT CASE WHEN (SELECT state FROM external_operation WHERE id=NEW.operation_id)<>'succeeded'
    THEN RAISE(ABORT,'qualification verdict requires successful operation') END;
END;

CREATE TRIGGER integration_operation_consistency
BEFORE INSERT ON integration_operation
BEGIN
  SELECT CASE WHEN (SELECT plan_id FROM attempt WHERE id=(SELECT attempt_id FROM terminal_receipt WHERE id=NEW.terminal_receipt_id))<>NEW.plan_id
    THEN RAISE(ABORT,'integration receipt plan mismatch') END;
  SELECT CASE WHEN (SELECT candidate_revision FROM terminal_receipt WHERE id=NEW.terminal_receipt_id)<>NEW.expected_candidate_revision
    THEN RAISE(ABORT,'integration candidate mismatch') END;
END;

CREATE TRIGGER integration_receipt_guard
BEFORE INSERT ON integration_receipt
BEGIN
  SELECT CASE WHEN NEW.plan_id<>(SELECT plan_id FROM integration_operation WHERE operation_id=NEW.operation_id)
    OR NEW.terminal_receipt_id<>(SELECT terminal_receipt_id FROM integration_operation WHERE operation_id=NEW.operation_id)
    THEN RAISE(ABORT,'integration receipt request mismatch') END;
  SELECT CASE WHEN (SELECT state FROM external_operation WHERE id=NEW.operation_id)<>'succeeded'
    THEN RAISE(ABORT,'integration receipt requires successful operation') END;
END;

CREATE TRIGGER artifact_guard
BEFORE INSERT ON artifact
BEGIN
  SELECT CASE WHEN NEW.plan_id<>(SELECT plan_id FROM production_operation WHERE operation_id=NEW.production_operation_id)
    OR NEW.integration_receipt_id<>(SELECT integration_receipt_id FROM production_operation WHERE operation_id=NEW.production_operation_id)
    THEN RAISE(ABORT,'artifact production request mismatch') END;
  SELECT CASE WHEN (SELECT state FROM external_operation WHERE id=NEW.production_operation_id)<>'succeeded'
    THEN RAISE(ABORT,'artifact requires successful production') END;
END;

CREATE TRIGGER publication_receipt_guard
BEFORE INSERT ON publication_receipt
BEGIN
  SELECT CASE WHEN NEW.artifact_id<>(SELECT artifact_id FROM publication_operation WHERE operation_id=NEW.operation_id)
    OR NEW.target_ref<>(SELECT target_ref FROM publication_operation WHERE operation_id=NEW.operation_id)
    THEN RAISE(ABORT,'publication receipt request mismatch') END;
  SELECT CASE WHEN (SELECT state FROM external_operation WHERE id=NEW.operation_id)<>'succeeded'
    THEN RAISE(ABORT,'publication receipt requires successful operation') END;
END;

CREATE TRIGGER external_operation_event_no_update
BEFORE UPDATE ON external_operation_event
BEGIN
  SELECT RAISE(ABORT,'external_operation_event is immutable');
END;
CREATE TRIGGER external_operation_event_no_delete
BEFORE DELETE ON external_operation_event
BEGIN
  SELECT RAISE(ABORT,'external_operation_event is immutable');
END;

CREATE TRIGGER operation_scope_claim_no_update
BEFORE UPDATE ON operation_scope_claim
BEGIN
  SELECT RAISE(ABORT,'operation_scope_claim is immutable');
END;
CREATE TRIGGER operation_scope_claim_no_delete
BEFORE DELETE ON operation_scope_claim
BEGIN
  SELECT RAISE(ABORT,'operation_scope_claim is immutable');
END;

CREATE TRIGGER worktree_create_operation_no_update
BEFORE UPDATE ON worktree_create_operation
BEGIN
  SELECT RAISE(ABORT,'worktree_create_operation is immutable');
END;
CREATE TRIGGER worktree_create_operation_no_delete
BEFORE DELETE ON worktree_create_operation
BEGIN
  SELECT RAISE(ABORT,'worktree_create_operation is immutable');
END;

CREATE TRIGGER worktree_remove_operation_no_update
BEFORE UPDATE ON worktree_remove_operation
BEGIN
  SELECT RAISE(ABORT,'worktree_remove_operation is immutable');
END;
CREATE TRIGGER worktree_remove_operation_no_delete
BEFORE DELETE ON worktree_remove_operation
BEGIN
  SELECT RAISE(ABORT,'worktree_remove_operation is immutable');
END;

CREATE TRIGGER session_acquire_operation_no_update
BEFORE UPDATE ON session_acquire_operation
BEGIN
  SELECT RAISE(ABORT,'session_acquire_operation is immutable');
END;
CREATE TRIGGER session_acquire_operation_no_delete
BEFORE DELETE ON session_acquire_operation
BEGIN
  SELECT RAISE(ABORT,'session_acquire_operation is immutable');
END;

CREATE TRIGGER session_release_operation_no_update
BEFORE UPDATE ON session_release_operation
BEGIN
  SELECT RAISE(ABORT,'session_release_operation is immutable');
END;
CREATE TRIGGER session_release_operation_no_delete
BEFORE DELETE ON session_release_operation
BEGIN
  SELECT RAISE(ABORT,'session_release_operation is immutable');
END;

CREATE TRIGGER launch_operation_no_update
BEFORE UPDATE ON launch_operation
BEGIN
  SELECT RAISE(ABORT,'launch_operation is immutable');
END;
CREATE TRIGGER launch_operation_no_delete
BEFORE DELETE ON launch_operation
BEGIN
  SELECT RAISE(ABORT,'launch_operation is immutable');
END;

CREATE TRIGGER worker_wake_operation_no_update
BEFORE UPDATE ON worker_wake_operation
BEGIN
  SELECT RAISE(ABORT,'worker_wake_operation is immutable');
END;
CREATE TRIGGER worker_wake_operation_no_delete
BEFORE DELETE ON worker_wake_operation
BEGIN
  SELECT RAISE(ABORT,'worker_wake_operation is immutable');
END;

CREATE TRIGGER interrupt_operation_no_update
BEFORE UPDATE ON interrupt_operation
BEGIN
  SELECT RAISE(ABORT,'interrupt_operation is immutable');
END;
CREATE TRIGGER interrupt_operation_no_delete
BEFORE DELETE ON interrupt_operation
BEGIN
  SELECT RAISE(ABORT,'interrupt_operation is immutable');
END;

CREATE TRIGGER executor_residual_cleanup_operation_no_update
BEFORE UPDATE ON executor_residual_cleanup_operation
BEGIN
  SELECT RAISE(ABORT,'executor_residual_cleanup_operation is immutable');
END;
CREATE TRIGGER executor_residual_cleanup_operation_no_delete
BEFORE DELETE ON executor_residual_cleanup_operation
BEGIN
  SELECT RAISE(ABORT,'executor_residual_cleanup_operation is immutable');
END;

CREATE TRIGGER qualification_operation_no_update
BEFORE UPDATE ON qualification_operation
BEGIN
  SELECT RAISE(ABORT,'qualification_operation is immutable');
END;
CREATE TRIGGER qualification_operation_no_delete
BEFORE DELETE ON qualification_operation
BEGIN
  SELECT RAISE(ABORT,'qualification_operation is immutable');
END;

CREATE TRIGGER integration_operation_no_update
BEFORE UPDATE ON integration_operation
BEGIN
  SELECT RAISE(ABORT,'integration_operation is immutable');
END;
CREATE TRIGGER integration_operation_no_delete
BEFORE DELETE ON integration_operation
BEGIN
  SELECT RAISE(ABORT,'integration_operation is immutable');
END;

CREATE TRIGGER production_operation_no_update
BEFORE UPDATE ON production_operation
BEGIN
  SELECT RAISE(ABORT,'production_operation is immutable');
END;
CREATE TRIGGER production_operation_no_delete
BEFORE DELETE ON production_operation
BEGIN
  SELECT RAISE(ABORT,'production_operation is immutable');
END;

CREATE TRIGGER publication_operation_no_update
BEFORE UPDATE ON publication_operation
BEGIN
  SELECT RAISE(ABORT,'publication_operation is immutable');
END;
CREATE TRIGGER publication_operation_no_delete
BEFORE DELETE ON publication_operation
BEGIN
  SELECT RAISE(ABORT,'publication_operation is immutable');
END;

CREATE TRIGGER launch_argument_no_update
BEFORE UPDATE ON launch_argument
BEGIN
  SELECT RAISE(ABORT,'launch_argument is immutable');
END;
CREATE TRIGGER launch_argument_no_delete
BEFORE DELETE ON launch_argument
BEGIN
  SELECT RAISE(ABORT,'launch_argument is immutable');
END;

CREATE TRIGGER launch_environment_no_update
BEFORE UPDATE ON launch_environment
BEGIN
  SELECT RAISE(ABORT,'launch_environment is immutable');
END;
CREATE TRIGGER launch_environment_no_delete
BEFORE DELETE ON launch_environment
BEGIN
  SELECT RAISE(ABORT,'launch_environment is immutable');
END;

CREATE TRIGGER attempt_worktree_binding_no_update
BEFORE UPDATE ON attempt_worktree_binding
BEGIN
  SELECT RAISE(ABORT,'attempt_worktree_binding is immutable');
END;
CREATE TRIGGER attempt_worktree_binding_no_delete
BEFORE DELETE ON attempt_worktree_binding
BEGIN
  SELECT RAISE(ABORT,'attempt_worktree_binding is immutable');
END;

CREATE TRIGGER worktree_binding_release_no_update
BEFORE UPDATE ON worktree_binding_release
BEGIN
  SELECT RAISE(ABORT,'worktree_binding_release is immutable');
END;
CREATE TRIGGER worktree_binding_release_no_delete
BEFORE DELETE ON worktree_binding_release
BEGIN
  SELECT RAISE(ABORT,'worktree_binding_release is immutable');
END;

CREATE TRIGGER session_binding_no_update
BEFORE UPDATE ON session_binding
BEGIN
  SELECT RAISE(ABORT,'session_binding is immutable');
END;
CREATE TRIGGER session_binding_no_delete
BEFORE DELETE ON session_binding
BEGIN
  SELECT RAISE(ABORT,'session_binding is immutable');
END;

CREATE TRIGGER session_binding_release_no_update
BEFORE UPDATE ON session_binding_release
BEGIN
  SELECT RAISE(ABORT,'session_binding_release is immutable');
END;
CREATE TRIGGER session_binding_release_no_delete
BEFORE DELETE ON session_binding_release
BEGIN
  SELECT RAISE(ABORT,'session_binding_release is immutable');
END;

CREATE TRIGGER executor_binding_no_update
BEFORE UPDATE ON executor_binding
BEGIN
  SELECT RAISE(ABORT,'executor_binding is immutable');
END;
CREATE TRIGGER executor_binding_no_delete
BEFORE DELETE ON executor_binding
BEGIN
  SELECT RAISE(ABORT,'executor_binding is immutable');
END;

CREATE TRIGGER executor_binding_termination_no_update
BEFORE UPDATE ON executor_binding_termination
BEGIN
  SELECT RAISE(ABORT,'executor_binding_termination is immutable');
END;
CREATE TRIGGER executor_binding_termination_no_delete
BEFORE DELETE ON executor_binding_termination
BEGIN
  SELECT RAISE(ABORT,'executor_binding_termination is immutable');
END;

CREATE TRIGGER worker_input_no_update
BEFORE UPDATE ON worker_input
BEGIN
  SELECT RAISE(ABORT,'worker_input is immutable');
END;
CREATE TRIGGER worker_input_no_delete
BEFORE DELETE ON worker_input
BEGIN
  SELECT RAISE(ABORT,'worker_input is immutable');
END;

CREATE TRIGGER worker_input_answer_origin_no_update
BEFORE UPDATE ON worker_input_answer_origin
BEGIN
  SELECT RAISE(ABORT,'worker_input_answer_origin is immutable');
END;
CREATE TRIGGER worker_input_answer_origin_no_delete
BEFORE DELETE ON worker_input_answer_origin
BEGIN
  SELECT RAISE(ABORT,'worker_input_answer_origin is immutable');
END;

CREATE TRIGGER worker_input_acknowledgement_no_update
BEFORE UPDATE ON worker_input_acknowledgement
BEGIN
  SELECT RAISE(ABORT,'worker_input_acknowledgement is immutable');
END;
CREATE TRIGGER worker_input_acknowledgement_no_delete
BEFORE DELETE ON worker_input_acknowledgement
BEGIN
  SELECT RAISE(ABORT,'worker_input_acknowledgement is immutable');
END;

CREATE TRIGGER worker_report_no_update
BEFORE UPDATE ON worker_report
BEGIN
  SELECT RAISE(ABORT,'worker_report is immutable');
END;
CREATE TRIGGER worker_report_no_delete
BEFORE DELETE ON worker_report
BEGIN
  SELECT RAISE(ABORT,'worker_report is immutable');
END;

CREATE TRIGGER worker_report_acknowledgement_no_update
BEFORE UPDATE ON worker_report_acknowledgement
BEGIN
  SELECT RAISE(ABORT,'worker_report_acknowledgement is immutable');
END;
CREATE TRIGGER worker_report_acknowledgement_no_delete
BEFORE DELETE ON worker_report_acknowledgement
BEGIN
  SELECT RAISE(ABORT,'worker_report_acknowledgement is immutable');
END;

CREATE TRIGGER decision_no_update
BEFORE UPDATE ON decision
BEGIN
  SELECT RAISE(ABORT,'decision is immutable');
END;
CREATE TRIGGER decision_no_delete
BEFORE DELETE ON decision
BEGIN
  SELECT RAISE(ABORT,'decision is immutable');
END;

CREATE TRIGGER decision_answer_no_update
BEFORE UPDATE ON decision_answer
BEGIN
  SELECT RAISE(ABORT,'decision_answer is immutable');
END;
CREATE TRIGGER decision_answer_no_delete
BEFORE DELETE ON decision_answer
BEGIN
  SELECT RAISE(ABORT,'decision_answer is immutable');
END;

CREATE TRIGGER decision_closure_no_update
BEFORE UPDATE ON decision_closure
BEGIN
  SELECT RAISE(ABORT,'decision_closure is immutable');
END;
CREATE TRIGGER decision_closure_no_delete
BEFORE DELETE ON decision_closure
BEGIN
  SELECT RAISE(ABORT,'decision_closure is immutable');
END;

CREATE TRIGGER task_hold_no_update
BEFORE UPDATE ON task_hold
BEGIN
  SELECT RAISE(ABORT,'task_hold is immutable');
END;
CREATE TRIGGER task_hold_no_delete
BEFORE DELETE ON task_hold
BEGIN
  SELECT RAISE(ABORT,'task_hold is immutable');
END;

CREATE TRIGGER task_hold_blocked_on_task_no_update
BEFORE UPDATE ON task_hold_blocked_on_task
BEGIN
  SELECT RAISE(ABORT,'task_hold_blocked_on_task is immutable');
END;
CREATE TRIGGER task_hold_blocked_on_task_no_delete
BEFORE DELETE ON task_hold_blocked_on_task
BEGIN
  SELECT RAISE(ABORT,'task_hold_blocked_on_task is immutable');
END;

CREATE TRIGGER task_hold_decision_no_update
BEFORE UPDATE ON task_hold_decision
BEGIN
  SELECT RAISE(ABORT,'task_hold_decision is immutable');
END;
CREATE TRIGGER task_hold_decision_no_delete
BEFORE DELETE ON task_hold_decision
BEGIN
  SELECT RAISE(ABORT,'task_hold_decision is immutable');
END;

CREATE TRIGGER task_hold_recheck_no_update
BEFORE UPDATE ON task_hold_recheck
BEGIN
  SELECT RAISE(ABORT,'task_hold_recheck is immutable');
END;
CREATE TRIGGER task_hold_recheck_no_delete
BEFORE DELETE ON task_hold_recheck
BEGIN
  SELECT RAISE(ABORT,'task_hold_recheck is immutable');
END;

CREATE TRIGGER task_hold_resolution_no_update
BEFORE UPDATE ON task_hold_resolution
BEGIN
  SELECT RAISE(ABORT,'task_hold_resolution is immutable');
END;
CREATE TRIGGER task_hold_resolution_no_delete
BEFORE DELETE ON task_hold_resolution
BEGIN
  SELECT RAISE(ABORT,'task_hold_resolution is immutable');
END;

CREATE TRIGGER task_archive_no_update
BEFORE UPDATE ON task_archive
BEGIN
  SELECT RAISE(ABORT,'task_archive is immutable');
END;
CREATE TRIGGER task_archive_no_delete
BEFORE DELETE ON task_archive
BEGIN
  SELECT RAISE(ABORT,'task_archive is immutable');
END;

CREATE TRIGGER attempt_backoff_no_update
BEFORE UPDATE ON attempt_backoff
BEGIN
  SELECT RAISE(ABORT,'attempt_backoff is immutable');
END;
CREATE TRIGGER attempt_backoff_no_delete
BEFORE DELETE ON attempt_backoff
BEGIN
  SELECT RAISE(ABORT,'attempt_backoff is immutable');
END;

CREATE TRIGGER attempt_backoff_resolution_no_update
BEFORE UPDATE ON attempt_backoff_resolution
BEGIN
  SELECT RAISE(ABORT,'attempt_backoff_resolution is immutable');
END;
CREATE TRIGGER attempt_backoff_resolution_no_delete
BEFORE DELETE ON attempt_backoff_resolution
BEGIN
  SELECT RAISE(ABORT,'attempt_backoff_resolution is immutable');
END;

CREATE TRIGGER repair_target_no_update
BEFORE UPDATE ON repair_target
BEGIN
  SELECT RAISE(ABORT,'repair_target is immutable');
END;
CREATE TRIGGER repair_target_no_delete
BEFORE DELETE ON repair_target
BEGIN
  SELECT RAISE(ABORT,'repair_target is immutable');
END;

CREATE TRIGGER repair_no_update
BEFORE UPDATE ON repair
BEGIN
  SELECT RAISE(ABORT,'repair is immutable');
END;
CREATE TRIGGER repair_no_delete
BEFORE DELETE ON repair
BEGIN
  SELECT RAISE(ABORT,'repair is immutable');
END;

CREATE TRIGGER repair_resolution_no_update
BEFORE UPDATE ON repair_resolution
BEGIN
  SELECT RAISE(ABORT,'repair_resolution is immutable');
END;
CREATE TRIGGER repair_resolution_no_delete
BEFORE DELETE ON repair_resolution
BEGIN
  SELECT RAISE(ABORT,'repair_resolution is immutable');
END;

CREATE TRIGGER terminal_receipt_no_update
BEFORE UPDATE ON terminal_receipt
BEGIN
  SELECT RAISE(ABORT,'terminal_receipt is immutable');
END;
CREATE TRIGGER terminal_receipt_no_delete
BEFORE DELETE ON terminal_receipt
BEGIN
  SELECT RAISE(ABORT,'terminal_receipt is immutable');
END;

CREATE TRIGGER qualification_verdict_no_update
BEFORE UPDATE ON qualification_verdict
BEGIN
  SELECT RAISE(ABORT,'qualification_verdict is immutable');
END;
CREATE TRIGGER qualification_verdict_no_delete
BEFORE DELETE ON qualification_verdict
BEGIN
  SELECT RAISE(ABORT,'qualification_verdict is immutable');
END;

CREATE TRIGGER integration_receipt_no_update
BEFORE UPDATE ON integration_receipt
BEGIN
  SELECT RAISE(ABORT,'integration_receipt is immutable');
END;
CREATE TRIGGER integration_receipt_no_delete
BEFORE DELETE ON integration_receipt
BEGIN
  SELECT RAISE(ABORT,'integration_receipt is immutable');
END;

CREATE TRIGGER artifact_no_update
BEFORE UPDATE ON artifact
BEGIN
  SELECT RAISE(ABORT,'artifact is immutable');
END;
CREATE TRIGGER artifact_no_delete
BEFORE DELETE ON artifact
BEGIN
  SELECT RAISE(ABORT,'artifact is immutable');
END;

CREATE TRIGGER publication_receipt_no_update
BEFORE UPDATE ON publication_receipt
BEGIN
  SELECT RAISE(ABORT,'publication_receipt is immutable');
END;
CREATE TRIGGER publication_receipt_no_delete
BEFORE DELETE ON publication_receipt
BEGIN
  SELECT RAISE(ABORT,'publication_receipt is immutable');
END;

CREATE TRIGGER legacy_import_no_update
BEFORE UPDATE ON legacy_import
BEGIN
  SELECT RAISE(ABORT,'legacy_import is immutable');
END;
CREATE TRIGGER legacy_import_no_delete
BEFORE DELETE ON legacy_import
BEGIN
  SELECT RAISE(ABORT,'legacy_import is immutable');
END;

CREATE TRIGGER legacy_import_project_no_update
BEFORE UPDATE ON legacy_import_project
BEGIN
  SELECT RAISE(ABORT,'legacy_import_project is immutable');
END;
CREATE TRIGGER legacy_import_project_no_delete
BEFORE DELETE ON legacy_import_project
BEGIN
  SELECT RAISE(ABORT,'legacy_import_project is immutable');
END;

CREATE TRIGGER fleet_no_update BEFORE UPDATE ON fleet BEGIN SELECT RAISE(ABORT,'fleet immutable'); END;
CREATE TRIGGER fleet_no_delete BEFORE DELETE ON fleet BEGIN SELECT RAISE(ABORT,'fleet immutable'); END;
CREATE TRIGGER project_no_delete BEFORE DELETE ON project BEGIN SELECT RAISE(ABORT,'project history immutable'); END;
CREATE TRIGGER workspace_binding_no_delete BEFORE DELETE ON workspace_binding BEGIN SELECT RAISE(ABORT,'workspace history immutable'); END;
CREATE TRIGGER policy_revision_no_delete BEFORE DELETE ON policy_revision BEGIN SELECT RAISE(ABORT,'policy history immutable'); END;
CREATE TRIGGER task_no_delete BEFORE DELETE ON task BEGIN SELECT RAISE(ABORT,'task history immutable'); END;
CREATE TRIGGER plan_no_delete BEFORE DELETE ON plan BEGIN SELECT RAISE(ABORT,'plan history immutable'); END;
CREATE TRIGGER attempt_no_delete BEFORE DELETE ON attempt BEGIN SELECT RAISE(ABORT,'attempt history immutable'); END;
CREATE TRIGGER external_operation_no_delete BEFORE DELETE ON external_operation BEGIN SELECT RAISE(ABORT,'operation history immutable'); END;

CREATE TRIGGER workspace_binding_update_guard
BEFORE UPDATE ON workspace_binding
BEGIN
  SELECT CASE WHEN
    NEW.id<>OLD.id OR NEW.project_id<>OLD.project_id OR NEW.ordinal<>OLD.ordinal OR
    NEW.repository_locator<>OLD.repository_locator OR
    NEW.repository_identity_digest<>OLD.repository_identity_digest OR
    NEW.common_git_dir<>OLD.common_git_dir OR
    NEW.physical_identity_digest<>OLD.physical_identity_digest OR
    NEW.revision<>OLD.revision OR NEW.established_at<>OLD.established_at
  THEN RAISE(ABORT,'workspace binding immutable fields') END;
  SELECT CASE WHEN OLD.superseded_at<>'' AND NEW.superseded_at<>OLD.superseded_at
    THEN RAISE(ABORT,'workspace binding already superseded') END;
END;

CREATE TRIGGER policy_revision_update_guard
BEFORE UPDATE ON policy_revision
BEGIN
  SELECT CASE WHEN
    NEW.id<>OLD.id OR NEW.project_id<>OLD.project_id OR NEW.ordinal<>OLD.ordinal OR
    NEW.policy_digest<>OLD.policy_digest OR NEW.worker_profile_ref<>OLD.worker_profile_ref OR
    NEW.qualification_policy_ref<>OLD.qualification_policy_ref OR
    NEW.integration_policy_ref<>OLD.integration_policy_ref OR
    NEW.production_policy_ref<>OLD.production_policy_ref OR
    NEW.publication_policy_ref<>OLD.publication_policy_ref OR NEW.created_at<>OLD.created_at
  THEN RAISE(ABORT,'policy revision immutable fields') END;
  SELECT CASE WHEN OLD.superseded_at<>'' AND NEW.superseded_at<>OLD.superseded_at
    THEN RAISE(ABORT,'policy revision already superseded') END;
END;

CREATE TRIGGER project_update_guard
BEFORE UPDATE ON project
BEGIN
  SELECT CASE WHEN NEW.id<>OLD.id OR NEW.fleet_id<>OLD.fleet_id OR NEW.ordinal<>OLD.ordinal OR NEW.created_at<>OLD.created_at
    THEN RAISE(ABORT,'project immutable fields') END;
  SELECT CASE WHEN OLD.retired_at<>'' AND NEW.retired_at<>OLD.retired_at
    THEN RAISE(ABORT,'project already retired') END;
END;


CREATE TRIGGER worktree_remove_operation_owner_guard
BEFORE INSERT ON worktree_remove_operation
BEGIN
  SELECT CASE WHEN (SELECT adapter_ref FROM external_operation WHERE id=NEW.operation_id)<>'builtin/git-worktree'
    THEN RAISE(ABORT,'worktree remove adapter') END;
  SELECT CASE WHEN (SELECT primary_scope_kind FROM external_operation WHERE id=NEW.operation_id)<>'worktree'
    OR (SELECT primary_scope_key FROM external_operation WHERE id=NEW.operation_id)<>NEW.binding_id
    THEN RAISE(ABORT,'worktree remove primary scope') END;
  SELECT CASE WHEN (SELECT attempt_id FROM external_operation WHERE id=NEW.operation_id) IS NOT
                        (SELECT attempt_id FROM attempt_worktree_binding WHERE id=NEW.binding_id)
    THEN RAISE(ABORT,'worktree remove owner mismatch') END;
  SELECT CASE WHEN NEW.expected_physical_identity_digest<>(SELECT physical_identity_digest FROM attempt_worktree_binding WHERE id=NEW.binding_id)
    OR NEW.expected_common_git_dir<>(SELECT common_git_dir FROM attempt_worktree_binding WHERE id=NEW.binding_id)
    OR NEW.expected_private_git_dir<>(SELECT private_git_dir FROM attempt_worktree_binding WHERE id=NEW.binding_id)
    OR NEW.expected_lock_reason<>(SELECT lock_reason FROM attempt_worktree_binding WHERE id=NEW.binding_id)
    OR NEW.expected_head_revision<>(SELECT head_revision FROM attempt_worktree_binding WHERE id=NEW.binding_id)
    THEN RAISE(ABORT,'worktree remove exact identity mismatch') END;
END;

CREATE TRIGGER worktree_create_operation_scope_guard
BEFORE INSERT ON worktree_create_operation
BEGIN
  SELECT CASE WHEN (SELECT primary_scope_kind FROM external_operation WHERE id=NEW.operation_id)<>'worktree'
    OR (SELECT primary_scope_key FROM external_operation WHERE id=NEW.operation_id)<>NEW.binding_id
    THEN RAISE(ABORT,'worktree create primary scope') END;
END;

CREATE TRIGGER session_acquire_operation_owner_guard
BEFORE INSERT ON session_acquire_operation
BEGIN
  SELECT CASE WHEN (SELECT primary_scope_kind FROM external_operation WHERE id=NEW.operation_id)<>'session'
    OR (SELECT primary_scope_key FROM external_operation WHERE id=NEW.operation_id)<>NEW.binding_id
    THEN RAISE(ABORT,'session acquire primary scope') END;
  SELECT CASE WHEN (SELECT adapter_ref FROM external_operation WHERE id=NEW.operation_id)<>
                        (SELECT session_adapter_ref FROM attempt WHERE id=NEW.attempt_id)
    THEN RAISE(ABORT,'session acquire adapter mismatch') END;
END;

CREATE TRIGGER session_release_operation_owner_guard
BEFORE INSERT ON session_release_operation
BEGIN
  SELECT CASE WHEN (SELECT primary_scope_kind FROM external_operation WHERE id=NEW.operation_id)<>'session'
    OR (SELECT primary_scope_key FROM external_operation WHERE id=NEW.operation_id)<>NEW.session_binding_id
    THEN RAISE(ABORT,'session release primary scope') END;
  SELECT CASE WHEN (SELECT attempt_id FROM external_operation WHERE id=NEW.operation_id) IS NOT
                        (SELECT attempt_id FROM session_binding WHERE id=NEW.session_binding_id)
    THEN RAISE(ABORT,'session release owner mismatch') END;
  SELECT CASE WHEN (SELECT adapter_ref FROM external_operation WHERE id=NEW.operation_id)<>
                        (SELECT adapter_ref FROM session_binding WHERE id=NEW.session_binding_id)
    THEN RAISE(ABORT,'session release adapter mismatch') END;
  SELECT CASE WHEN NEW.expected_provider_session_key<>(SELECT provider_session_key FROM session_binding WHERE id=NEW.session_binding_id)
    THEN RAISE(ABORT,'session release provider key mismatch') END;
END;

CREATE TRIGGER launch_operation_owner_guard
BEFORE INSERT ON launch_operation
BEGIN
  SELECT CASE WHEN (SELECT primary_scope_kind FROM external_operation WHERE id=NEW.operation_id)<>'executor-control'
    OR (SELECT primary_scope_key FROM external_operation WHERE id=NEW.operation_id)<>NEW.binding_id
    THEN RAISE(ABORT,'launch primary scope') END;
  SELECT CASE WHEN (SELECT adapter_ref FROM external_operation WHERE id=NEW.operation_id)<>
                        (SELECT adapter_ref FROM session_binding WHERE id=NEW.session_binding_id)
    THEN RAISE(ABORT,'launch adapter mismatch') END;
END;

CREATE TRIGGER worker_wake_operation_consistency
BEFORE INSERT ON worker_wake_operation
BEGIN
  SELECT CASE WHEN (SELECT primary_scope_kind FROM external_operation WHERE id=NEW.operation_id)<>'executor-control'
    OR (SELECT primary_scope_key FROM external_operation WHERE id=NEW.operation_id)<>NEW.executor_binding_id
    THEN RAISE(ABORT,'worker wake primary scope') END;
  SELECT CASE WHEN (SELECT attempt_id FROM external_operation WHERE id=NEW.operation_id) IS NOT NEW.attempt_id
    THEN RAISE(ABORT,'worker wake operation owner mismatch') END;
  SELECT CASE WHEN (SELECT attempt_id FROM session_binding WHERE id=NEW.session_binding_id)<>NEW.attempt_id
    OR (SELECT attempt_id FROM executor_binding WHERE id=NEW.executor_binding_id)<>NEW.attempt_id
    OR (SELECT session_binding_id FROM executor_binding WHERE id=NEW.executor_binding_id)<>NEW.session_binding_id
    THEN RAISE(ABORT,'worker wake exact binding mismatch') END;
  SELECT CASE WHEN (SELECT adapter_ref FROM external_operation WHERE id=NEW.operation_id)<>
                        (SELECT adapter_ref FROM executor_binding WHERE id=NEW.executor_binding_id)
    THEN RAISE(ABORT,'worker wake adapter mismatch') END;
  SELECT CASE WHEN (SELECT lifecycle FROM attempt WHERE id=NEW.attempt_id)<>'active'
    THEN RAISE(ABORT,'worker wake stale attempt') END;
  SELECT CASE WHEN EXISTS (SELECT 1 FROM session_binding_release WHERE session_binding_id=NEW.session_binding_id)
    OR EXISTS (SELECT 1 FROM executor_binding_termination WHERE executor_binding_id=NEW.executor_binding_id)
    THEN RAISE(ABORT,'worker wake closed binding') END;
  SELECT CASE WHEN NOT EXISTS (
    SELECT 1
    FROM worker_input wi
    WHERE wi.executor_binding_id=NEW.executor_binding_id
      AND wi.ordinal<=NEW.pending_through_ordinal
      AND NOT EXISTS (
        SELECT 1 FROM worker_input_acknowledgement a WHERE a.worker_input_id=wi.id
      )
  ) THEN RAISE(ABORT,'worker wake requires pending input') END;
  SELECT CASE WHEN NEW.pending_through_ordinal >
      COALESCE((SELECT max(ordinal) FROM worker_input WHERE executor_binding_id=NEW.executor_binding_id),0)
    THEN RAISE(ABORT,'worker wake boundary beyond input') END;
END;

CREATE TRIGGER interrupt_operation_consistency
BEFORE INSERT ON interrupt_operation
BEGIN
  SELECT CASE WHEN (SELECT primary_scope_kind FROM external_operation WHERE id=NEW.operation_id)<>'executor-control'
    OR (SELECT primary_scope_key FROM external_operation WHERE id=NEW.operation_id)<>NEW.executor_binding_id
    THEN RAISE(ABORT,'interrupt primary scope') END;
  SELECT CASE WHEN (SELECT attempt_id FROM external_operation WHERE id=NEW.operation_id) IS NOT NEW.attempt_id
    OR (SELECT attempt_id FROM executor_binding WHERE id=NEW.executor_binding_id)<>NEW.attempt_id
    THEN RAISE(ABORT,'interrupt exact binding mismatch') END;
  SELECT CASE WHEN (SELECT adapter_ref FROM external_operation WHERE id=NEW.operation_id)<>
                        (SELECT adapter_ref FROM executor_binding WHERE id=NEW.executor_binding_id)
    THEN RAISE(ABORT,'interrupt adapter mismatch') END;
  SELECT CASE WHEN (SELECT lifecycle FROM attempt WHERE id=NEW.attempt_id)<>'active'
    THEN RAISE(ABORT,'interrupt stale attempt') END;
  SELECT CASE WHEN EXISTS (SELECT 1 FROM executor_binding_termination WHERE executor_binding_id=NEW.executor_binding_id)
    THEN RAISE(ABORT,'interrupt closed executor') END;
END;

CREATE TRIGGER executor_residual_cleanup_operation_consistency
BEFORE INSERT ON executor_residual_cleanup_operation
BEGIN
  SELECT CASE WHEN (SELECT primary_scope_kind FROM external_operation WHERE id=NEW.operation_id)<>'executor-control'
    OR (SELECT primary_scope_key FROM external_operation WHERE id=NEW.operation_id)<>NEW.executor_binding_id
    THEN RAISE(ABORT,'residual cleanup primary scope') END;
  SELECT CASE WHEN (SELECT attempt_id FROM external_operation WHERE id=NEW.operation_id) IS NOT NEW.attempt_id
    OR (SELECT attempt_id FROM executor_binding WHERE id=NEW.executor_binding_id)<>NEW.attempt_id
    THEN RAISE(ABORT,'residual cleanup exact binding mismatch') END;
  SELECT CASE WHEN (SELECT adapter_ref FROM external_operation WHERE id=NEW.operation_id)<>
                        (SELECT adapter_ref FROM executor_binding WHERE id=NEW.executor_binding_id)
    THEN RAISE(ABORT,'residual cleanup adapter mismatch') END;
END;

CREATE TRIGGER qualification_operation_owner_guard
BEFORE INSERT ON qualification_operation
BEGIN
  SELECT CASE WHEN (SELECT primary_scope_kind FROM external_operation WHERE id=NEW.operation_id)<>'qualification'
    OR (SELECT primary_scope_key FROM external_operation WHERE id=NEW.operation_id)<>NEW.plan_id
    THEN RAISE(ABORT,'qualification primary scope') END;
  SELECT CASE WHEN (SELECT plan_id FROM external_operation WHERE id=NEW.operation_id) IS NOT NEW.plan_id
    THEN RAISE(ABORT,'qualification operation plan mismatch') END;
END;

CREATE TRIGGER integration_operation_owner_guard
BEFORE INSERT ON integration_operation
BEGIN
  SELECT CASE WHEN (SELECT primary_scope_kind FROM external_operation WHERE id=NEW.operation_id)<>'integration'
    OR (SELECT primary_scope_key FROM external_operation WHERE id=NEW.operation_id)<>NEW.plan_id
    THEN RAISE(ABORT,'integration primary scope') END;
  SELECT CASE WHEN (SELECT plan_id FROM external_operation WHERE id=NEW.operation_id) IS NOT NEW.plan_id
    THEN RAISE(ABORT,'integration operation plan mismatch') END;
END;

CREATE TRIGGER production_operation_consistency
BEFORE INSERT ON production_operation
BEGIN
  SELECT CASE WHEN (SELECT primary_scope_kind FROM external_operation WHERE id=NEW.operation_id)<>'production'
    OR (SELECT primary_scope_key FROM external_operation WHERE id=NEW.operation_id)<>NEW.plan_id
    THEN RAISE(ABORT,'production primary scope') END;
  SELECT CASE WHEN (SELECT plan_id FROM external_operation WHERE id=NEW.operation_id) IS NOT NEW.plan_id
    THEN RAISE(ABORT,'production operation plan mismatch') END;
  SELECT CASE WHEN (SELECT plan_id FROM integration_receipt WHERE operation_id=NEW.integration_receipt_id)<>NEW.plan_id
    THEN RAISE(ABORT,'production integration plan mismatch') END;
END;

CREATE TRIGGER publication_operation_consistency
BEFORE INSERT ON publication_operation
BEGIN
  SELECT CASE WHEN (SELECT primary_scope_kind FROM external_operation WHERE id=NEW.operation_id)<>'publication'
    OR (SELECT primary_scope_key FROM external_operation WHERE id=NEW.operation_id)<>NEW.artifact_id
    THEN RAISE(ABORT,'publication primary scope') END;
  SELECT CASE WHEN (SELECT plan_id FROM external_operation WHERE id=NEW.operation_id) IS NOT
                        (SELECT plan_id FROM artifact WHERE id=NEW.artifact_id)
    THEN RAISE(ABORT,'publication operation plan mismatch') END;
END;

PRAGMA user_version = 19;
